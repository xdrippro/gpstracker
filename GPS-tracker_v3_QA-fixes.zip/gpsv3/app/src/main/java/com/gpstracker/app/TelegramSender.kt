package com.gpstracker.app

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

object TelegramSender {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS).callTimeout(30, TimeUnit.SECONDS).build()
    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    suspend fun send(botToken: String, chatId: String, html: String): SendResult = withContext(Dispatchers.IO) {
        if (botToken.isBlank() || chatId.isBlank() || !botToken.trim().matches(Regex("\\d+:[A-Za-z0-9_-]{20,}")))
            return@withContext SendResult.ConfigError("Bot token yoki chat ID bo'sh/noto'g'ri")
        try {
            val url = "https://api.telegram.org/bot${botToken.trim().removePrefix("bot")}/sendMessage"
            val body = JSONObject().put("chat_id", chatId.trim()).put("text", html).put("parse_mode", "HTML")
                .toString().toRequestBody(JSON_MEDIA_TYPE)
            client.newCall(Request.Builder().url(url).post(body).build()).execute().use { r ->
                val payload = runCatching { JSONObject(r.body?.string().orEmpty()) }.getOrNull()
                val apiOk = payload?.optBoolean("ok", false) == true
                when {
                    r.isSuccessful && apiOk -> SendResult.Success
                    r.code == 429 || r.code >= 500 || r.code == 408 -> SendResult.Retryable("HTTP ${r.code}")
                    r.code in listOf(400, 401, 403, 404) -> SendResult.ConfigError(payload?.optString("description") ?: "HTTP ${r.code}")
                    !r.isSuccessful -> SendResult.Retryable("HTTP ${r.code}")
                    else -> SendResult.Retryable(payload?.optString("description") ?: "Telegram API javobi ok=true emas")
                }
            }
        } catch (e: CancellationException) { throw e }
        catch (e: SocketTimeoutException) { SendResult.Retryable("Timeout") }
        catch (e: IOException) { Log.e("TelegramSender", "Network error", e); SendResult.Retryable("Network error") }
        catch (e: Exception) { Log.e("TelegramSender", "Unexpected send error", e); SendResult.Retryable(e.javaClass.simpleName) }
    }
}

sealed interface SendResult {
    data object Success : SendResult
    data class Retryable(val reason: String) : SendResult
    data class ConfigError(val reason: String) : SendResult
}
