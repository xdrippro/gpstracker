package com.gpstracker.app

import android.util.Log
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Koordinatalar uchun mavjud token AES-GCM Keystore kalitidan foydalanadi; yangi kalit yaratmaydi. */
object LocationCrypto {
    private const val KEY_ALIAS = "gpstracker_token_key"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG = "LocationCrypto"

    private fun existingKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        return (ks.getKey(KEY_ALIAS, null) as? SecretKey)
            ?: throw IllegalStateException("Mavjud GPS Tracker Keystore kaliti topilmadi; koordinata shifrlanmadi")
    }

    fun encryptCoordinates(value: Double): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, existingKey())
        val iv = cipher.iv
        val encrypted = cipher.doFinal(ByteBuffer.allocate(8).putDouble(value).array())
        return ByteArrayOutputStream().apply { write(iv); write(encrypted) }.toByteArray()
    }

    fun decryptCoordinates(blob: ByteArray): Double {
        require(blob.size >= 12 + 16) { "Shifrlangan koordinata BLOB noto'g'ri" }
        val iv = blob.copyOfRange(0, 12)
        val cipherTextAndTag = blob.copyOfRange(12, blob.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, existingKey(), GCMParameterSpec(128, iv))
        return ByteBuffer.wrap(cipher.doFinal(cipherTextAndTag)).double
    }

    fun encryptLegacyRows(db: android.database.sqlite.SQLiteDatabase) {
        val rows = mutableListOf<Triple<Long, Double, Double>>()
        db.rawQuery("SELECT id,lat,lng FROM location_queue WHERE lat IS NOT NULL AND lng IS NOT NULL AND lat_enc IS NULL AND lng_enc IS NULL", null).use { c ->
            while (c.moveToNext()) rows.add(Triple(c.getLong(0), c.getDouble(1), c.getDouble(2)))
        }
        rows.forEach { (id, lat, lng) ->
            val cv = android.content.ContentValues().apply {
                put("lat_enc", encryptCoordinates(lat)); put("lng_enc", encryptCoordinates(lng))
                putNull("lat"); putNull("lng")
            }
            db.update("location_queue", cv, "id=?", arrayOf(id.toString()))
        }
        Log.i(TAG, "Migrated ${rows.size} legacy coordinate rows")
    }
}
