package com.gpstracker.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED,
                "android.intent.action.QUICKBOOT_POWERON", "com.htc.intent.action.QUICKBOOT_POWERON")) return
        val app = context.applicationContext
        val prefs = AppPrefs.prefs(app)
        if (!prefs.getBoolean(AppPrefs.KEY_TRACKING, false)) return
        if (AppPrefs.getBotToken(app).isBlank() || prefs.getString(AppPrefs.KEY_CHAT_ID, "").isNullOrBlank()) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            Log.w(TAG, "Tracking reset: Telegram config missing")
            return
        }
        val fine = ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val background = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || ContextCompat.checkSelfPermission(app, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        val notifications = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if ((!fine && !coarse) || !background || !notifications) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            showPermissionNotification(app)
            Log.w(TAG, "Tracking not restarted: location/background/notification permission missing")
            return
        }
        // Battery optimization is advisory, not a runtime permission; log it but don't block tracking.
        val pm = app.getSystemService(PowerManager::class.java)
        Log.d(TAG, "Battery optimization ignored=${pm?.isIgnoringBatteryOptimizations(app.packageName)}")
        try {
            ContextCompat.startForegroundService(app, Intent(app, TrackingService::class.java).setAction(TrackingService.ACTION_START))
            Log.i(TAG, "Tracking foreground service start requested")
        } catch (e: SecurityException) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            showPermissionNotification(app)
            Log.e(TAG, "SecurityException starting service", e)
        } catch (e: android.app.ForegroundServiceStartNotAllowedException) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            showPermissionNotification(app)
            Log.e(TAG, "Android blocked foreground service launch", e)
        } catch (e: Exception) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            Log.e(TAG, "Could not start foreground service: ${e.javaClass.simpleName}", e)
        }
    }

    private fun showPermissionNotification(c: Context) {
        val manager = c.getSystemService(NotificationManager::class.java)
        val channelId = "gps_tracker_permission"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channelId, "GPS Tracker ruxsatlari", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 304, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager.notify(304, NotificationCompat.Builder(c, channelId).setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("GPS Tracker").setContentText("Kuzatuvni qayta yoqish uchun ruxsat kerak")
            .setContentIntent(open).setAutoCancel(true).build())
    }
    companion object { private const val TAG = "BootReceiver" }
}
