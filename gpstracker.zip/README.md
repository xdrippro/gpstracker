GPS TRACKER: ILOVA HAQIDA

ASOSIY MA'LUMOT
Nomi: GPS Tracker
Paket: com.gpstracker.app
Versiya: 1.2.0 (versionCode 3)
Android: 10 va undan yuqori (minSdk 29, targetSdk 37)
Texnologiya: Kotlin, Jetpack Compose
Vazifasi: telefon joylashuvini Telegram bot orqali yuboradi. Internet yo'q bo'lsa SMS orqali yuboradi. Telefon yo'qolsa, SMS buyruq bilan joyini aniqlash va sirena chaldirish mumkin.

FUNKSIYALAR
1. Telegram kuzatuvi
- Joylashuv har soatda Telegram botga yuboriladi.
- Xabarda: ism, vaqt, kenglik, uzunlik, aniqlik (metr), tezlik, batareya foizi, tarmoq turi, Google Maps havolasi.
- Telefon bir joyda tursa ham har 3 soatda "tirikman" nuqtasi yuboriladi.
- Xato bo'lsa 5 daqiqadan keyin qayta uriniladi.
- 5 daqiqadan eski keshdagi joylashuv yuborilmaydi.

2. Internet yo'q bo'lganda
- Nuqtalar telefonda saqlanadi.
- Internet qaytganda hammasi bitta xabarga birlashib Telegram'ga ketadi (vaqt va batareya foizi bilan).

3. SMS zaxirasi
- Internet yo'q, lekin 2G/3G tarmoq bor bo'lsa, oxirgi nuqta saqlangan raqamga SMS qilinadi.
- SMS matni: ism, sana-vaqt, Google Maps havolasi.
- Cheklov: 30 daqiqada 1 ta SMS.
- Internet bor, lekin Telegram ishlamasa, SMS'dan oldin 2 daqiqa kutadi.
- SMS yuborilganda bildirishnoma chiqadi, doimiy bildirishnomada "SMS orqali yuborildi" va sana ko'rinadi.

4. Qayta yoqilganda avtomatik ishga tushish
- Telefon reboot bo'lsa ilova o'zi ishga tushadi.
- Telegram'ga "qayta ishga tushdi" xabari 1-4 daqiqada keladi.
- Internet hali tayyor bo'lmagani uchun SMS zaxirasi ham ishlab ketishi mumkin (normal holat).

5. PIN kod
- Ilovaga kirish uchun 4 xonali PIN. Xeshlangan (tuz bilan) saqlanadi.

6. Masofaviy SMS buyruqlar (pastda)

SMS BUYRUQLAR
Faqat saqlangan raqamdan va to'g'ri maxfiy kod bilan ishlaydi. Boshqa raqamga javob yo'q. Harf kattaligi farq qilmaydi.

JOY 1234 - joylashuvni SMS bilan qaytaradi
JOY OVOZ 1234 - sirena + chiroq miltillashi + joylashuv SMS
JOY STOP 1234 - sirena va chiroqni to'xtatadi
(1234 o'rniga o'zingiz qo'ygan 4 xonali kod. 0000 faqat sinov uchun.)

Sirena:
- Telefonning standart budilnik ovozi, budilnik kanalida chaladi (ovozsiz va "Bezovta qilmang" rejimida ham eshitiladi).
- Alohida ovoz fayli yo'q.
- 60 soniyadan keyin o'zi to'xtaydi. Bildirishnomadagi "To'xtatish" tugmasi yoki JOY STOP bilan ham to'xtaydi.

Buyruq xavfsizligi:
- Kod hash holatida saqlanadi.
- 3 marta xato kod: 1 soat bloklanadi.
- Joylashuv javobi 5 daqiqada 1 ta.
- Har buyruqda bildirishnoma chiqadi.

RUXSATLAR VA NIMAGA KERAK
Joylashuv (aniq, taxminiy): GPS koordinatasi
Fonda joylashuv: ilova yopiq bo'lsa ham joyni olish
Fon xizmati (FOREGROUND_SERVICE, LOCATION, DATA_SYNC): kuzatuv va buyruqlar fonda to'xtamasligi
Internet, tarmoq holati: Telegram'ga yuborish, internet bor-yo'qligini bilish
SEND_SMS: SMS zaxirasi va buyruq javobi
RECEIVE_SMS: JOY buyruqlarini qabul qilish
RECEIVE_BOOT_COMPLETED: telefon yoqilganda o'zi ishga tushish
POST_NOTIFICATIONS: bildirishnomalar
WAKE_LOCK: joyni aniqlayotganda telefon uxlab qolmasligi
REQUEST_IGNORE_BATTERY_OPTIMIZATIONS: tizim ilovani fonda o'chirmasligi
SCHEDULE_EXACT_ALARM, USE_EXACT_ALARM: keyingi joylashuv vaqtini aniq belgilash
Chiroq va budilnik ovozi uchun alohida ruxsat kerak emas.

CHEKLOVLAR
- "Majburan to'xtatish" (Force stop) qilinsa, qayta ochilmaguncha kuzatuv ham, SMS buyruq ham ishlamaydi.
- Telefon o'chiq yoki tarmoq signali yo'q bo'lsa SMS ketmaydi, nuqtalar saqlanib keyin yuboriladi.
- Fon xizmati bildirishnomasini siljitib o'chirib bo'lmaydi, "To'xtatish" tugmasi bor.
- SMS operator tarifi bo'yicha pullik bo'lishi mumkin.
- SMS ochiq matnda ketadi (ism, vaqt, joylashuv havolasi).