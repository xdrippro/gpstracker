# GPS Tracker v3 — QA fixes in this patch

## Build configuration found in source
- applicationId / namespace: `com.gpstracker.app`
- minSdk: 29 (Android 10)
- targetSdk: 37
- compileSdk: 37
- Java/Kotlin target: 17

## Applied changes
1. Telegram sender now returns `Success`, `Retryable(reason)`, or `ConfigError(reason)`, checks HTTP status and Telegram JSON `ok`, and treats network/timeout errors as retryable.
2. Queue flush only marks rows sent after `Success`; failures persist `retry_count` and `last_error`. WorkManager's existing exponential backoff is used on retry. Last error is stored in `telegram_send_error` for UI to display.
3. Queue DB version upgraded to 2; migration adds retry metadata and encrypted coordinate columns. New coordinates use the existing `gpstracker_token_key` AES-GCM key; the 12-byte IV is prepended to ciphertext+tag. Existing plaintext coordinates are migrated in `onUpgrade` and nulled after encryption. No new key is created by `LocationCrypto`.
4. Queue retention now removes rows older than seven days and adds a timestamp index.
5. BootReceiver checks location/background/notification permissions, catches service-launch failures, resets tracking state on failure and posts a notification linking to MainActivity. Battery optimization is logged as advisory because it is not a runtime permission.
6. MainActivity no longer marks tracking active when background location permission is denied.

## Important verification notes
- This archive was not built or run on a physical device in this environment. A Gradle wrapper JAR is absent, and a local Gradle executable was not available, so build success is NOT claimed.
- Before production release, run `assembleDebug`, Android 10/12/13/14+ device tests, and unit/instrumentation tests for HTTP 400/401/403/429/500, timeout/offline, migration with an existing Keystore key, and a fresh install where no key exists yet.
- The existing GitHub Actions workflow builds a debug APK only. It does not configure release signing; do not put a keystore or passwords in the repository. Configure GitHub Actions secrets and a release signing step before distributing a release APK.
- `telegram_send_error` is stored in preferences; the UI must render it to show the requested warning. This patch does not add a new Compose warning banner.
- Check that a configured token is present before first queue insertion: `LocationCrypto` intentionally refuses to create a new key, as requested. If the app is upgraded from a version that never created `gpstracker_token_key`, DB migration will fail rather than leave legacy coordinates plaintext; back up/export the queue before upgrading such a device.
