package com.gpstracker.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Network
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TrackingService : Service() {

    private lateinit var prefs: SharedPreferences
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, e -> Log.e(TAG, "Coroutine xato", e) })
    private var cycleJob: Job? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null

    @Volatile
    private var isStopped = false

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_HOURLY_TRIGGER = "ACTION_HOURLY_TRIGGER"
        const val CHANNEL_ID = "gps_tracker_channel"
        const val NOTIFICATION_ID = 1001
        private const val TAG = "TrackingService"
        private const val ALARM_REQUEST_CODE = 1002
        const val INTERVAL_HOURLY_MS = 60 * 60 * 1000L
        const val INTERVAL_RETRY_MS = 5 * 60 * 1000L
        private const val WAKELOCK_TIMEOUT_MS = 120_000L
        @Volatile var instance: TrackingService? = null
    }

    /** Internet yo'q, joylashuv SMS orqali ketganda doimiy bildirishnomani yangilaydi. */
    fun showSmsSent() {
        val now = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        updateNotification("SMS orqali yuborildi: $now")
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = AppPrefs.prefs(this)
        createNotificationChannel()
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GpsTracker:cycle")
            .apply { setReferenceCounted(false) }

        // Internet paydo bo'lishi bilan navbatni eskisidan boshlab yuboradi
        val cm = getSystemService(ConnectivityManager::class.java)
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                scope.launch {
                    if (!TrackingCore.flush(applicationContext)) Scheduler.enqueueSync(applicationContext)
                }
            }
        }
        try { cm.registerDefaultNetworkCallback(cb); netCallback = cb }
        catch (e: Exception) { Log.w(TAG, "NetworkCallback: ${e.javaClass.simpleName}") }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_HOURLY_TRIGGER

        if (action == ACTION_STOP) {
            isStopped = true
            stopForegroundTracking()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val isInitial = action == ACTION_START

        try {
            startForeground(NOTIFICATION_ID, buildOngoingNotification("GPS kuzatuv faol..."))
        } catch (e: SecurityException) {
            // Ruxsat bekor qilingan: haqiqatan to'xtatamiz
            Log.e(TAG, "startForeground: ruxsat yo'q")
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            isStopped = true
            stopSelf()
            return START_NOT_STICKY
        } catch (e: Exception) {
            // Fonda start taqiqlangan: flag O'ZGARMAYDI, Watchdog zanjirni davom ettiradi
            Log.w(TAG, "startForeground taqiqlangan: ${e.javaClass.simpleName}")
            Scheduler.startWatchdog(this)
            Scheduler.enqueueSync(this)
            stopSelf()
            return START_NOT_STICKY
        }

        if (isInitial) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, true).apply()
            Scheduler.startWatchdog(this)
        } else if (!prefs.getBoolean(AppPrefs.KEY_TRACKING, false)) {
            isStopped = true
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        isStopped = false
        if (isInitial && TrackingCore.lastAlive(this) == 0L) TrackingCore.markAlive(this) else TrackingCore.checkGap(this)
        scheduleNextAlarm(INTERVAL_HOURLY_MS)
        runCycle(isInitial)
        return START_STICKY
    }

    private fun runCycle(isInitial: Boolean) {
        if (cycleJob?.isActive == true) return
        cycleJob = scope.launch {
            try { wakeLock?.acquire(WAKELOCK_TIMEOUT_MS) } catch (e: Exception) {}
            try {
                val cap = TrackingCore.captureAndStore(applicationContext, isInitial)
                val ok = cap != CaptureResult.Failed
                if (!ok) scheduleNextAlarm(INTERVAL_RETRY_MS)
                val flushed = TrackingCore.flush(applicationContext)
                if (!flushed) Scheduler.enqueueSync(applicationContext)
                else if (ok) {
                    val now = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                    val err = prefs.getString("telegram_send_error", null)
                    updateNotification(
                        when {
                            !err.isNullOrBlank() -> "Yuborilmadi: $err ($now)"
                            cap == CaptureResult.Filtered -> "Oxirgi tekshiruv: $now (joy o'zgarmagan, yuborilmadi)"
                            else -> "Oxirgi yuborilgan vaqt: $now"
                        }
                    )
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "runCycle xato", e)
                scheduleNextAlarm(INTERVAL_RETRY_MS)
                Scheduler.enqueueSync(applicationContext)
            } finally {
                releaseWakeLockSafely()
            }
        }
    }

    private fun releaseWakeLockSafely() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) {}
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Recent'dan surilganda OEM servisni o'ldirishi mumkin: zaxirani kafolatlaymiz
        if (!isStopped && prefs.getBoolean(AppPrefs.KEY_TRACKING, false)) {
            scheduleNextAlarm(30_000L)
            Scheduler.startWatchdog(this)
        }
        super.onTaskRemoved(rootIntent)
    }

    /**
     * setAndAllowWhileIdle: SCHEDULE_EXACT_ALARM ruxsatini talab qilmaydi va Doze rejimida ham ishlaydi.
     * Vaqt aniq emas (bir necha daqiqa og'ishi mumkin), soatlik hisobot uchun bu yetarli.
     */
    private fun scheduleNextAlarm(delayMs: Long) {
        if (isStopped) return
        val pendingIntent = alarmPendingIntent(noCreate = false) ?: return
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val at = SystemClock.elapsedRealtime() + delayMs
        val canExact = android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.S ||
            alarmManager.canScheduleExactAlarms()
        try {
            if (canExact) alarmManager.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pendingIntent)
            else alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pendingIntent)
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pendingIntent)
        }
    }

    private fun alarmPendingIntent(noCreate: Boolean): PendingIntent? {
        val triggerIntent = Intent(this, TrackingService::class.java).apply {
            action = ACTION_HOURLY_TRIGGER
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or
                (if (noCreate) PendingIntent.FLAG_NO_CREATE else PendingIntent.FLAG_UPDATE_CURRENT)
        return PendingIntent.getForegroundService(this, ALARM_REQUEST_CODE, triggerIntent, flags)
    }

    private fun stopForegroundTracking() {
        prefs.edit().remove("last_alive_ts").apply()   // qo'lda to'xtatish uzilish hisoblanmaydi
        // BootReceiver va UI qayta yoqib yubormasligi uchun
        prefs.edit()
            .putBoolean(AppPrefs.KEY_TRACKING, false)
            .putInt(AppPrefs.KEY_LOCATION_FAILS, 0)
            .putInt(AppPrefs.KEY_SEND_FAILS, 0)
            .apply()

        val pendingIntent = alarmPendingIntent(noCreate = true)
        if (pendingIntent != null) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }

        Scheduler.stopWatchdog(this)
        releaseWakeLockSafely()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "GPS Tracker Doimiy Xizmati",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Har 1 soatda GPS joylashuvni Telegramga jo'natish xizmati"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildOngoingNotification(content: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpenApp = PendingIntent.getActivity(
            this, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE
        )

        // Bildirishnomadagi "To'xtatish" tugmasi ilovani ochadi: PIN kiritilgach to'xtatish tasdiqlanadi.
        val stopIntent = Intent(this, MainActivity::class.java).apply {
            action = MainActivity.ACTION_REQUEST_STOP
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingStop = PendingIntent.getActivity(
            this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GPS Tracker Faol")
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingOpenApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_delete, "To'xtatish", pendingStop)
            .build()
    }

    private fun updateNotification(content: String) {
        // STOP'dan keyin kechikib kelgan callback bildirishnomani qayta chiqarib yubormasligi uchun
        if (isStopped) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildOngoingNotification(content))
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        isStopped = true
        scope.cancel()
        netCallback?.let {
            try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } catch (e: Exception) {}
        }
        netCallback = null
        releaseWakeLockSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
