package com.gpstracker.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.security.MessageDigest

object SmsCommand {
    fun hash(ctx: Context, code: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest("$code:${ctx.packageName}".toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    /** Oxirgi 9 raqam bo'yicha solishtiradi (+998 XX XXX XX XX). */
    fun sameNumber(a: String, b: String): Boolean {
        val x = a.filter { it.isDigit() }.takeLast(9)
        val y = b.filter { it.isDigit() }.takeLast(9)
        return x.length == 9 && x == y
    }
}

/**
 * "JOY 1234" buyrug'i: faqat saqlangan raqamdan va to'g'ri maxfiy kod bilan ishlaydi.
 * 3 marta xato kod: 1 soat bloklanadi. 5 daqiqada 1 ta javob. Har so'rovda bildirishnoma chiqadi.
 */
class SmsCommandReceiver : BroadcastReceiver() {
    private companion object {
        const val K_FAILS = "sms_cmd_fails"
        const val K_LOCK_UNTIL = "sms_cmd_lock_until"
        const val K_LAST_REPLY = "sms_cmd_last_reply"
        val CMD = Regex("^JOY(?:\\s+(OVOZ|STOP))?\\s+(\\d{4})$", RegexOption.IGNORE_CASE)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val p = AppPrefs.prefs(ctx)
        val phone = p.getString(AppPrefs.KEY_SMS_PHONE, "").orEmpty()
        val hash = p.getString(AppPrefs.KEY_SMS_CODE_HASH, "").orEmpty()
        if (phone.isEmpty() || hash.isEmpty()) return

        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        val sender = msgs.firstOrNull()?.originatingAddress ?: return
        val body = msgs.joinToString("") { it.messageBody.orEmpty() }.trim()
        val m = CMD.matchEntire(body) ?: return
        val action = m.groupValues[1].uppercase()   // "", "OVOZ" yoki "STOP"
        val code = m.groupValues[2]

        if (!SmsCommand.sameNumber(sender, phone)) return          // boshqa raqam: javob yo'q
        val now = System.currentTimeMillis()
        if (now < p.getLong(K_LOCK_UNTIL, 0L)) return              // bloklangan

        if (SmsCommand.hash(ctx, code) != hash) {
            val fails = p.getInt(K_FAILS, 0) + 1
            if (fails >= 3) p.edit().putInt(K_FAILS, 0).putLong(K_LOCK_UNTIL, now + 3600_000L).apply()
            else p.edit().putInt(K_FAILS, fails).apply()
            SmsFallback.notify(ctx, "Noto'g'ri SMS buyruq kodi", "JOY buyrug'i noto'g'ri kod bilan keldi ($fails/3)")
            return
        }
        p.edit().putInt(K_FAILS, 0).apply()
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (action == "STOP") { wm.cancelUniqueWork(FindPhoneWorker.WORK_NAME); return }
        if (action == "OVOZ") {
            val find = OneTimeWorkRequestBuilder<FindPhoneWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST).build()
            wm.enqueueUniqueWork(FindPhoneWorker.WORK_NAME, ExistingWorkPolicy.REPLACE, find)
        }
        if (now - p.getLong(K_LAST_REPLY, 0L) < 5 * 60_000L) return // 5 daqiqada 1 ta javob
        p.edit().putLong(K_LAST_REPLY, now).apply()

        val req = OneTimeWorkRequestBuilder<RemoteLocateWorker>()
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST).build()
        WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork("remote_locate", ExistingWorkPolicy.KEEP, req)
    }
}

class RemoteLocateWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun getForegroundInfo(): ForegroundInfo {
        SmsFallback.ensureChannel(applicationContext)
        val n = NotificationCompat.Builder(applicationContext, SmsFallback.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Masofaviy so'rov")
            .setContentText("Joylashuv aniqlanmoqda...")
            .setOngoing(true).build()
        return ForegroundInfo(2002, n)
    }

    override suspend fun doWork(): Result {
        val app = applicationContext
        val phone = AppPrefs.prefs(app).getString(AppPrefs.KEY_SMS_PHONE, "").orEmpty()
        if (phone.isEmpty()) return Result.success()
        SmsFallback.notify(app, "Masofaviy so'rov", "SMS buyrug'i keldi, joylashuv yuborilmoqda")

        val stored = try { TrackingCore.captureAndStore(app, isInitial = false, force = true) }
        catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { CaptureResult.Failed }

        val e = TrackingCore.lastStored
        val text = if (stored == CaptureResult.Stored && e != null) SmsFallback.format(app, e, "(Masofaviy so'rov)")
        else "GPS Tracker: joyni aniqlab bo'lmadi (GPS signali yo'q)"
        val ok = SmsFallback.send(app, phone, text)
        SmsFallback.notify(app, "Masofaviy so'rov", if (ok) "Joylashuv $phone raqamiga yuborildi" else "SMS yuborib bo'lmadi")

        runCatching { TrackingCore.flush(app) }   // internet bor bo'lsa Telegram'ga ham ketadi
        return Result.success()
    }
}
