package com.gpstracker.app

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class SyncWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = try {
        runCatching { AdminAlert.deliver(applicationContext, allowSms = false) }   // internet qaytdi: kutayotgan ogohlantirish
        if (TrackingCore.flush(applicationContext)) Result.success() else Result.retry()
    } catch (e: kotlinx.coroutines.CancellationException) { throw e }
    catch (e: Exception) { Result.retry() }
}

/** Servis o'lgan bo'lsa ham lokatsiyani o'zi oladi va navbatni yuboradi. */
class WatchdogWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        runCatching { AdminAlert.deliver(app, allowSms = true) }   // kutayotgan ogohlantirish: Telegram, bo'lmasa SMS
        if (!AppPrefs.prefs(app).getBoolean(AppPrefs.KEY_TRACKING, false)) return Result.success()

        TrackingCore.checkGap(app)
        val last = TrackingCore.lastAlive(app)
        if (System.currentTimeMillis() - last > 65 * 60_000L) {
            runCatching {
                ContextCompat.startForegroundService(
                    app, Intent(app, TrackingService::class.java).setAction(TrackingService.ACTION_HOURLY_TRIGGER)
                )
            }
            try { TrackingCore.captureAndStore(app, isInitial = false) }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Exception) { /* keyingi 15 daqiqada qayta uriniladi */ }
        }
        val flushed = try { TrackingCore.flush(app) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (e: Exception) { false }
        if (!flushed) Scheduler.enqueueSync(app)

        return Result.success()
    }
}

object Scheduler {
    fun enqueueSync(ctx: Context) {
        val req = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork("sync", ExistingWorkPolicy.KEEP, req)
    }
    fun startWatchdog(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<WatchdogWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("watchdog", ExistingPeriodicWorkPolicy.KEEP, req)
    }
    fun stopWatchdog(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork("watchdog")
    }
}
