package com.gpstracker.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class LocationEntry(
    val id: Long = 0,
    val timestamp: Long,
    val lat: Double, val lng: Double,
    val accuracy: Float, val speedKmh: Float,
    val battery: Int, val charging: Boolean,
    val network: String,
    val isInitial: Boolean,
    val isSent: Boolean = false,
    val warning: String? = null
)

/** Offline navbat (SQLite). Room/KSP o'rniga: telefonda build qilishda plagin xavfi yo'q. */
class QueueDb private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "tracker.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE location_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp INTEGER NOT NULL," +
            "lat REAL, lng REAL, accuracy REAL, speedKmh REAL, battery INTEGER, charging INTEGER," +
            "network TEXT, isInitial INTEGER, isSent INTEGER NOT NULL DEFAULT 0, retry_count INTEGER NOT NULL DEFAULT 0, last_error TEXT, lat_enc BLOB, lng_enc BLOB, warning TEXT)"
        )
        db.execSQL("CREATE INDEX idx_sent_ts ON location_queue(isSent, timestamp)")
        db.execSQL("CREATE INDEX idx_created_at ON location_queue(timestamp)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE location_queue ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE location_queue ADD COLUMN last_error TEXT")
            db.execSQL("ALTER TABLE location_queue ADD COLUMN lat_enc BLOB")
            db.execSQL("ALTER TABLE location_queue ADD COLUMN lng_enc BLOB")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_created_at ON location_queue(timestamp)")
            // Existing rows are encrypted in-place with the already provisioned token key.
            // If the key is missing, abort the transaction instead of silently keeping plaintext.
            LocationCrypto.encryptLegacyRows(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE location_queue ADD COLUMN warning TEXT")
        }
    }

    suspend fun insert(e: LocationEntry) = withContext(Dispatchers.IO) {
        val cv = ContentValues().apply {
            put("timestamp", e.timestamp)
            put("lat_enc", LocationCrypto.encryptCoordinates(e.lat)); put("lng_enc", LocationCrypto.encryptCoordinates(e.lng))
            putNull("lat"); putNull("lng")
            put("accuracy", e.accuracy); put("speedKmh", e.speedKmh); put("battery", e.battery)
            put("charging", if (e.charging) 1 else 0); put("network", e.network)
            put("isInitial", if (e.isInitial) 1 else 0); put("isSent", 0)
            put("warning", e.warning)
        }
        writableDatabase.insert("location_queue", null, cv)
        // Navbat 5000 dan oshmasin (eng eskilari o'chadi)
        writableDatabase.execSQL(
            "DELETE FROM location_queue WHERE isSent=0 AND id NOT IN " +
            "(SELECT id FROM location_queue WHERE isSent=0 ORDER BY timestamp DESC LIMIT 5000)"
        )
    }

    suspend fun unsent(n: Int): List<LocationEntry> = withContext(Dispatchers.IO) {
        val out = ArrayList<LocationEntry>()
        val bad = ArrayList<Long>()
        readableDatabase.rawQuery(
            "SELECT id,timestamp,lat,lng,accuracy,speedKmh,battery,charging,network,isInitial,retry_count,last_error,lat_enc,lng_enc,warning " +
            "FROM location_queue WHERE isSent=0 ORDER BY timestamp ASC LIMIT ?", arrayOf(n.toString())
        ).use { c ->
            while (c.moveToNext()) {
                try {
                    out.add(
                        LocationEntry(
                            id = c.getLong(0), timestamp = c.getLong(1),
                            lat = if (!c.isNull(12)) LocationCrypto.decryptCoordinates(c.getBlob(12)) else c.getDouble(2),
                            lng = if (!c.isNull(13)) LocationCrypto.decryptCoordinates(c.getBlob(13)) else c.getDouble(3),
                            accuracy = c.getFloat(4), speedKmh = c.getFloat(5), battery = c.getInt(6),
                            charging = c.getInt(7) == 1, network = c.getString(8) ?: "", isInitial = c.getInt(9) == 1,
                            warning = c.getString(14)
                        )
                    )
                } catch (e: Exception) { bad.add(c.getLong(0)) }   // deshifrlab bo'lmaydi: qaytarib bo'lmas qator
            }
        }
        if (bad.isNotEmpty()) {
            writableDatabase.execSQL("UPDATE location_queue SET isSent=1,last_error='decrypt failed' WHERE id IN (${bad.joinToString(",")})")
        }
        out
    }

    suspend fun markSent(id: Long) = withContext(Dispatchers.IO) {
        writableDatabase.execSQL("UPDATE location_queue SET isSent=1 WHERE id=?", arrayOf(id))
    }

    suspend fun markSentIds(ids: List<Long>) = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext
        writableDatabase.execSQL("UPDATE location_queue SET isSent=1 WHERE id IN (${ids.joinToString(",")})")
    }

    suspend fun lastEntry(): LocationEntry? = withContext(Dispatchers.IO) {
        readableDatabase.rawQuery(
            "SELECT timestamp,lat,lng,lat_enc,lng_enc FROM location_queue ORDER BY timestamp DESC LIMIT 1", null
        ).use {
            if (it.moveToFirst()) try { LocationEntry(
                timestamp = it.getLong(0),
                lat = if (!it.isNull(3)) LocationCrypto.decryptCoordinates(it.getBlob(3)) else it.getDouble(1),
                lng = if (!it.isNull(4)) LocationCrypto.decryptCoordinates(it.getBlob(4)) else it.getDouble(2),
                accuracy = 0f, speedKmh = 0f, battery = 0, charging = false, network = "", isInitial = false
            ) } catch (e: Exception) { null } else null
        }
    }


    suspend fun recordFailure(ids: List<Long>, error: String) = withContext(Dispatchers.IO) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            ids.forEach { id -> db.execSQL("UPDATE location_queue SET retry_count=retry_count+1,last_error=? WHERE id=?", arrayOf<Any>(error.take(300), id)) }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    suspend fun purgeOlderThan(before: Long) = withContext(Dispatchers.IO) {
        writableDatabase.execSQL("DELETE FROM location_queue WHERE timestamp<?", arrayOf(before))
    }

    suspend fun pendingCount(): Int = withContext(Dispatchers.IO) {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM location_queue WHERE isSent=0", null)
            .use { if (it.moveToFirst()) it.getInt(0) else 0 }
    }

    suspend fun lastTimestamp(): Long = withContext(Dispatchers.IO) {
        readableDatabase.rawQuery("SELECT MAX(timestamp) FROM location_queue", null)
            .use { if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else 0L }
    }

    suspend fun purgeSent(before: Long) = withContext(Dispatchers.IO) {
        writableDatabase.execSQL("DELETE FROM location_queue WHERE isSent=1 AND timestamp<?", arrayOf(before))
    }

    companion object {
        @Volatile private var inst: QueueDb? = null
        fun get(ctx: Context): QueueDb = inst ?: synchronized(this) {
            inst ?: QueueDb(ctx).also { inst = it }
        }
    }
}
