package com.gpstracker.app

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object PermissionHelper {

    fun fineLocationOk(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun backgroundLocationOk(c: Context) =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun notificationsOk(c: Context) = NotificationManagerCompat.from(c).areNotificationsEnabled()

    fun batteryOk(c: Context) =
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    private fun launch(c: Context, i: Intent): Boolean = try {
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    fun requestIgnoreBattery(c: Context) {
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}"))
        if (!launch(c, direct)) launch(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    fun openAppSettings(c: Context) {
        launch(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}")))
    }

    // Xiaomi, Realme/Oppo, Vivo, Huawei, Samsung "Autostart / ishga tushirish" ekranlari
    private val AUTOSTART = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.startupapp.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
    )

    /** Autostart ekrani ochilsa true; topilmasa ilova sozlamalariga o'tadi (false). */
    fun openAutostart(c: Context): Boolean {
        for ((pkg, cls) in AUTOSTART) {
            if (launch(c, Intent().setComponent(ComponentName(pkg, cls)))) return true
        }
        openAppSettings(c)
        return false
    }
}

@Composable
fun OemSetupDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }   // "Qayta tekshirish" holatni yangilaydi
    @Suppress("UNUSED_EXPRESSION") tick

    fun mark(ok: Boolean) = if (ok) "✅" else "❌"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Fon rejimi sozlamalari") },
        text = {
            Column(Modifier.fillMaxWidth()) {
                Text("${mark(PermissionHelper.fineLocationOk(ctx))} Joylashuv ruxsati")
                Text("${mark(PermissionHelper.backgroundLocationOk(ctx))} Har doim joylashuv (Allow all the time)")
                Text("${mark(PermissionHelper.notificationsOk(ctx))} Bildirishnomalar")
                Text("${mark(PermissionHelper.batteryOk(ctx))} Batareya cheklovisiz")
                Text("\nRealme/Xiaomi/Oppo: Autostart'ni yoqing, Batareya = 'Cheklovsiz', ilovani recent'da qulflang.")
                Row {
                    TextButton(onClick = { PermissionHelper.openAppSettings(ctx) }) { Text("Ruxsatlar") }
                    TextButton(onClick = { PermissionHelper.requestIgnoreBattery(ctx) }) { Text("Batareya") }
                }
                TextButton(onClick = { PermissionHelper.openAutostart(ctx) }) { Text("Autostart sozlamasi") }
            }
        },
        confirmButton = { TextButton(onClick = { tick++ }) { Text("Qayta tekshirish") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Yopish") } }
    )
}
