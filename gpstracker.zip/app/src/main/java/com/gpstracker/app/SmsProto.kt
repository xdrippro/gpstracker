package com.gpstracker.app

import android.content.Context
import android.util.Base64
import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Shifrlangan SMS protokoli: AES-256-GCM, bitta umumiy tasodifiy kalit (QR orqali bir marta ulanadi).
 * SMS = Base64( IV(12) + shifrlangan payload + Tag(16) ). Yo'nalish AAD bilan ajratiladi (hajmga qo'shilmaydi).
 * Payload: [tur 1][vaqt 4] + N1: [lat 4][lng 4] (daraja*1e7) | JOY/JOY OVOZ: [parol 2]
 */
object SmsProto {
    const val T_N1: Byte = 0x01
    const val T_G7: Byte = 0x02
    const val T_HELLO: Byte = 0x03   // ulanish SMS'i: monitoring tracker raqamini shundan o'rganadi
    const val T_JOY: Byte = 0x10
    const val T_JOY_OVOZ: Byte = 0x11
    const val K_ONLY_ENC = "proto_only_encrypted"
    private const val K_KEY = "proto_key_enc"
    private const val K_LAST_IN = "proto_last_in_ts"
    private const val K_LAST_OUT = "proto_last_out_ts"
    private val AAD_T2M = byteArrayOf(0x01)   // Tracker -> Monitoring
    private val AAD_M2T = byteArrayOf(0x02)   // Monitoring -> Tracker
    private val B64 = Regex("^[A-Za-z0-9+/]{40,120}={0,2}$")
    private val rnd = SecureRandom()

    class Cmd(val type: Byte, val ts: Long, val password: Int)

    private fun p(ctx: Context) = AppPrefs.prefs(ctx)

    private fun key(ctx: Context): ByteArray? {
        val s = p(ctx).getString(K_KEY, null) ?: return null
        val b64 = AppPrefs.decrypt(s) ?: return null
        return runCatching { Base64.decode(b64, Base64.NO_WRAP) }.getOrNull()?.takeIf { it.size == 32 }
    }

    fun isPaired(ctx: Context) = key(ctx) != null

    /** Kalit yo'q bo'lsa yaratadi. QR uchun Base64 (44 belgi) qaytaradi. */
    @Synchronized
    fun ensureKeyBase64(ctx: Context): String {
        key(ctx)?.let { return Base64.encodeToString(it, Base64.NO_WRAP) }
        return regenerate(ctx)
    }

    /** QR ko'rsatish hisobi: har yangi kalitda 5 ta. */
    @Synchronized
    fun consumeQrView(ctx: Context): Boolean {
        val left = p(ctx).getInt("proto_qr_left", 5)
        if (left <= 0) return false
        p(ctx).edit().putInt("proto_qr_left", left - 1).apply()
        return true
    }

    @Synchronized
    fun regenerate(ctx: Context): String {
        val k = ByteArray(32).also { rnd.nextBytes(it) }
        val b64 = Base64.encodeToString(k, Base64.NO_WRAP)
        p(ctx).edit().putString(K_KEY, AppPrefs.encrypt(b64)).putLong(K_LAST_IN, 0L).putLong(K_LAST_OUT, 0L).putInt("proto_qr_left", 5).apply()
        return b64
    }

    private fun encrypt(ctx: Context, plain: ByteArray, aad: ByteArray): String? {
        val k = key(ctx) ?: return null
        return runCatching {
            val iv = ByteArray(12).also { rnd.nextBytes(it) }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, iv))
            c.updateAAD(aad)
            Base64.encodeToString(iv + c.doFinal(plain), Base64.NO_WRAP)
        }.getOrNull()
    }

    private fun decrypt(ctx: Context, b64: String, aad: ByteArray): ByteArray? {
        val k = key(ctx) ?: return null
        return runCatching {
            val raw = Base64.decode(b64, Base64.NO_WRAP)
            if (raw.size < 12 + 16 + 5) return null
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(k, "AES"), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            c.updateAAD(aad)
            c.doFinal(raw, 12, raw.size - 12)
        }.getOrNull()   // noto'g'ri kalit/o'zgartirilgan xabar: jim rad etiladi
    }

    /** Chiquvchi xabar vaqti: har doim oldingisidan katta (replay himoyasi uchun ham). */
    @Synchronized
    fun nextTs(ctx: Context): Long {
        val t = maxOf(System.currentTimeMillis() / 1000, p(ctx).getLong(K_LAST_OUT, 0L) + 1)
        p(ctx).edit().putLong(K_LAST_OUT, t).apply()
        return t
    }

    fun n1(ctx: Context, lat: Double, lng: Double, tsSec: Long): String? = encrypt(ctx,
        ByteBuffer.allocate(13).put(T_N1).putInt(tsSec.toInt())
            .putInt(Math.round(lat * 1e7).toInt()).putInt(Math.round(lng * 1e7).toInt()).array(), AAD_T2M)

    fun g7(ctx: Context, tsSec: Long): String? = encrypt(ctx,
        ByteBuffer.allocate(5).put(T_G7).putInt(tsSec.toInt()).array(), AAD_T2M)

    fun hello(ctx: Context, tsSec: Long): String? = encrypt(ctx,
        ByteBuffer.allocate(5).put(T_HELLO).putInt(tsSec.toInt()).array(), AAD_T2M)

    fun looksEncrypted(body: String) = B64.matches(body)

    /** Kelgan shifrlangan buyruqni ochadi (autentifikatsiya muvaffaqiyatsiz bo'lsa null). */
    fun parseCommand(ctx: Context, body: String): Cmd? {
        val d = decrypt(ctx, body, AAD_M2T) ?: return null
        if (d.size != 7) return null
        val bb = ByteBuffer.wrap(d)
        val type = bb.get()
        if (type != T_JOY && type != T_JOY_OVOZ) return null
        val ts = bb.getInt().toLong() and 0xFFFFFFFFL
        val pwd = bb.getShort().toInt() and 0xFFFF
        if (pwd > 9999) return null
        return Cmd(type, ts, pwd)
    }

    /** Buyruq faqat oxirgisidan yangi va 1 soatdan eski bo'lmasa qabul qilinadi (qayta yuborishdan himoya). */
    @Synchronized
    fun acceptIncoming(ctx: Context, ts: Long): Boolean {
        val now = System.currentTimeMillis() / 1000
        if (ts <= p(ctx).getLong(K_LAST_IN, 0L) || now - ts > 3600 || ts - now > 300) return false
        p(ctx).edit().putLong(K_LAST_IN, ts).apply()
        return true
    }
}
