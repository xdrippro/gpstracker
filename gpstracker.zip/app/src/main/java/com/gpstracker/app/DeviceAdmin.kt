package com.gpstracker.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import kotlinx.coroutines.runBlocking
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Qurilma administratori: ilovani sozlamalardan to'g'ridan-to'g'ri o'chirishni bloklaydi.
 * Hech qanday xavfli siyosat (wipe, lock va h.k.) ishlatilmaydi.
 * Administrator o'chirilsa Telegram va SMS orqali ogohlantirish ketadi.
 */
class DeviceAdmin : DeviceAdminReceiver() {
    companion object {
        const val K_SELF_DISABLE = "admin_self_disable"
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Himoya o'chiriladi va telefon egasiga ogohlantirish yuboriladi."

    override fun onDisabled(context: Context, intent: Intent) {
        val app = context.applicationContext
        val p = AppPrefs.prefs(app)
        if (p.getBoolean(K_SELF_DISABLE, false)) {      // ilovaning o'zidan o'chirilgan: ogohlantirish yo'q
            p.edit().putBoolean(K_SELF_DISABLE, false).apply()
            return
        }
        val pending = goAsync()
        Thread {
            try {
                val user = TextUtils.htmlEncode(p.getString(AppPrefs.KEY_USER_NAME, "Noma'lum").orEmpty())
                val time = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US).format(Date())
                val token = AppPrefs.getBotToken(app)
                val chatId = p.getString(AppPrefs.KEY_CHAT_ID, "").orEmpty()
                if (token.isNotBlank() && chatId.isNotBlank()) {
                    runCatching {
                        runBlocking {
                            TelegramSender.send(token, chatId,
                                "🚨 <b>GPS Tracker: Qurilma administratori o'chirildi!</b>\n" +
                                    "👤 Foydalanuvchi: $user\n⏰ Vaqt: $time\n" +
                                    "Kimdir ilovani o'chirishga urinayotgan bo'lishi mumkin.")
                        }
                    }
                }
                val phone = p.getString(AppPrefs.KEY_SMS_PHONE, "").orEmpty()
                if (phone.isNotBlank()) {
                    SmsFallback.send(app, phone, "GPS Tracker: $user\n$time\nQurilma administratori o'chirildi! Ilova o'chirilishi mumkin.")
                }
            } finally {
                pending.finish()
            }
        }.start()
    }
}
