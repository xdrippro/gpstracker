package com.gpstracker.app

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.text.TextUtils
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Qurilma administratori: ilovani sozlamalardan to'g'ridan-to'g'ri o'chirishni bloklaydi.
 * Hech qanday xavfli siyosat (wipe, lock va h.k.) ishlatilmaydi.
 * Administrator o'chirilsa ogohlantirish: Telegram, bo'lmasa SMS, internet (Wi-Fi) qaytsa Telegram.
 */
class DeviceAdmin : DeviceAdminReceiver() {
    companion object {
        const val K_SELF_DISABLE = "admin_self_disable"
        const val K_PENDING = "admin_alert_pending"      // Telegram'ga hali yetmagan ogohlantirish matni
        const val K_SMS_DONE = "admin_alert_sms_done"
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "Himoya o'chiriladi va telefon egasiga ogohlantirish yuboriladi."

    override fun onDisabled(context: Context, intent: Intent) {
        val app = context.applicationContext
        val p = AppPrefs.prefs(app)
        if (p.getBoolean(K_SELF_DISABLE, false)) {      // ilovaning o'zidan o'chirilgan: ogohlantirish yo'q
            p.edit().putBoolean(K_SELF_DISABLE, false).apply()
            return
        }
        val user = TextUtils.htmlEncode(p.getString(AppPrefs.KEY_USER_NAME, "Noma'lum").orEmpty())
        val time = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US).format(Date())
        val html = "🚨 <b>GPS Tracker: Qurilma administratori o'chirildi!</b>\n" +
            "👤 Foydalanuvchi: $user\n⏰ Vaqt: $time\n" +
            "Kimdir ilovani o'chirishga urinayotgan bo'lishi mumkin."
        p.edit().putString(K_PENDING, html).putBoolean(K_SMS_DONE, false).apply()

        // Darrov bir marta uriniladi; yetmasa mavjud 15 daqiqalik Watchdog davom ettiradi (alohida ish yo'q)
        WorkManager.getInstance(app).enqueueUniqueWork("admin_alert_now", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<AdminAlertWorker>()
                .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST).build())
        Scheduler.startWatchdog(app)
    }
}

/**
 * Ogohlantirish yetkazish: Telegram -> bo'lmasa SMS (antenna bo'lsa va haqiqatan ketsa, bir marta).
 * Telegram'ga yetmaguncha xotirada saqlanadi, Watchdog (har 15 daqiqa) va internet qaytganda qayta uriniladi.
 */
object AdminAlert {
    private val lock = kotlinx.coroutines.sync.Mutex()   // bir vaqtda ikki marta yuborilmasin

    suspend fun deliver(app: Context, allowSms: Boolean) = lock.withLock { deliverLocked(app, allowSms) }

    private suspend fun deliverLocked(app: Context, allowSms: Boolean) {
        val p = AppPrefs.prefs(app)
        val html = p.getString(DeviceAdmin.K_PENDING, null) ?: return
        val token = AppPrefs.getBotToken(app)
        val chatId = p.getString(AppPrefs.KEY_CHAT_ID, "").orEmpty()
        val telegramOk = token.isNotBlank() && chatId.isNotBlank() &&
            runCatching { TelegramSender.send(token, chatId, html) }.getOrNull() is SendResult.Success
        if (telegramOk) { p.edit().remove(DeviceAdmin.K_PENDING).apply(); return }
        if (!allowSms || p.getBoolean(DeviceAdmin.K_SMS_DONE, false)) return
        val phone = p.getString(AppPrefs.KEY_SMS_PHONE, "").orEmpty()
        if (phone.isBlank()) return
        val plain = html.replace(Regex("<[^>]*>"), "").replace("🚨 ", "").replace("👤 ", "").replace("⏰ ", "")
        if (SmsFallback.sendConfirmed(app, phone, plain)) {
            p.edit().putBoolean(DeviceAdmin.K_SMS_DONE, true).apply()
            SmsFallback.notify(app, "Administrator o'chirildi", "Ogohlantirish $phone raqamiga SMS qilindi")
        }
    }
}

class AdminAlertWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun getForegroundInfo(): ForegroundInfo {
        SmsFallback.ensureChannel(applicationContext)
        val n = NotificationCompat.Builder(applicationContext, SmsFallback.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("Ogohlantirish yuborilmoqda").setOngoing(true).build()
        return ForegroundInfo(2004, n)
    }

    override suspend fun doWork(): Result {
        AdminAlert.deliver(applicationContext, allowSms = true)
        return Result.success()
    }
}
