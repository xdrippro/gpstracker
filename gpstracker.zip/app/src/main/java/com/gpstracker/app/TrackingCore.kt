package com.gpstracker.app

import android.annotation.SuppressLint
import android.content.Context
import android.text.TextUtils
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CaptureResult { Stored, Filtered, Failed }

object TrackingCore {
    private const val MIN_DISTANCE_M = 30f                 // 4-band: shundan yaqin nuqta saqlanmaydi
    private const val HEARTBEAT_MS = 3 * 3600_000L         // joyida tursa ham har 3 soatda "tirikman" nuqtasi
    private const val GAP_THRESHOLD_MS = 95 * 60_000L      // 2-band: soatlik sikl (60 daq) + Doze kechikishi zaxirasi
    private const val BATCH_SIZE = 25                      // 1 xabarga nechta nuqta
    private const val SEND_PAUSE_MS = 1_100L               // Telegram: 1 xabar/soniya
    private const val K_ALIVE = "last_alive_ts"
    private const val K_GAP_REF = "gap_ref_ts"
    private const val K_GAP_TEXT = "gap_notice_text"

    private val flushMutex = Mutex()
    private const val LOCATION_TIMEOUT_MS = 30_000L

    @SuppressLint("MissingPermission")
    suspend fun captureAndStore(ctx: Context, isInitial: Boolean): CaptureResult {
        val app = ctx.applicationContext
        val client = LocationServices.getFusedLocationProviderClient(app)
        val loc = try {
            val cts = CancellationTokenSource()
            try {
                withTimeoutOrNull(LOCATION_TIMEOUT_MS) {
                    client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token).await()
                }
            } finally { cts.cancel() } ?: client.lastLocation.await()
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { null } ?: return CaptureResult.Failed

        val db = QueueDb.get(app)
        val last = db.lastEntry()
        if (!isInitial && last != null) {
            val d = FloatArray(1)
            android.location.Location.distanceBetween(last.lat, last.lng, loc.latitude, loc.longitude, d)
            if (d[0] < MIN_DISTANCE_M && System.currentTimeMillis() - last.timestamp < HEARTBEAT_MS) {
                markAlive(app)                 // servis tirik, lekin nuqta ortiqcha
                return CaptureResult.Filtered
            }
        }

        val (battery, charging) = DeviceUtils.getBatteryInfo(app)
        db.insert(
            LocationEntry(
                timestamp = System.currentTimeMillis(),
                lat = loc.latitude, lng = loc.longitude, accuracy = loc.accuracy,
                speedKmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f,
                battery = battery, charging = charging,
                network = DeviceUtils.getNetworkType(app), isInitial = isInitial
            )
        )
        markAlive(app)
        return CaptureResult.Stored
    }

    // ---- Gap detection (2-band)
    private fun p(ctx: Context) = AppPrefs.prefs(ctx)
    fun lastAlive(ctx: Context): Long = p(ctx).getLong(K_ALIVE, 0L)
    fun markAlive(ctx: Context) { p(ctx).edit().putLong(K_ALIVE, System.currentTimeMillis()).apply() }

    /** Servis/Watchdog qayta ishga tushganda chaqiriladi. Uzilish topilsa, ogohlantirish navbatga qo'yiladi. */
    fun checkGap(ctx: Context) {
        val pr = p(ctx)
        if (!pr.getBoolean(AppPrefs.KEY_TRACKING, false)) return
        val last = pr.getLong(K_ALIVE, 0L)
        if (last == 0L) return
        val gap = System.currentTimeMillis() - last
        if (gap < GAP_THRESHOLD_MS || pr.getLong(K_GAP_REF, 0L) == last) return
        val t = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val h = gap / 3600_000L
        val m = (gap % 3600_000L) / 60_000L
        val dur = if (h > 0) "$h soat $m daqiqa" else "$m daqiqa"
        val text = "⚠️ <b>Kuzatuv $dur davomida uzilgan edi</b>\n" +
            "🕒 ${t.format(Date(last))} → ${t.format(Date())}\n" +
            "✅ Aloqa tiklandi."
        pr.edit().putString(K_GAP_TEXT, text).putLong(K_GAP_REF, last).apply()
    }


    /** Navbat faqat Telegram API ok=true qaytarganda tozalanadi. */
    suspend fun flush(ctx: Context): Boolean = flushMutex.withLock {
        val app = ctx.applicationContext
        val token = AppPrefs.getBotToken(app)
        val prefs = AppPrefs.prefs(app)
        val chatId = prefs.getString(AppPrefs.KEY_CHAT_ID, "").orEmpty()
        if (token.isBlank() || chatId.isBlank()) {
            prefs.edit().putString("telegram_send_error", "Telegram token yoki chat ID kiritilmagan").apply()
            return true   // retry foydasiz: foydalanuvchi sozlamani to'g'rilashi kerak
        }
        val user = TextUtils.htmlEncode(prefs.getString(AppPrefs.KEY_USER_NAME, "Noma'lum").orEmpty())
        val db = QueueDb.get(app)
        prefs.edit().remove("telegram_send_error").apply()

        prefs.getString(K_GAP_TEXT, null)?.let { gap ->
            when (val result = TelegramSender.send(token, chatId, gap)) {
                SendResult.Success -> prefs.edit().remove(K_GAP_TEXT).apply()
                is SendResult.Unconfirmed -> prefs.edit().remove(K_GAP_TEXT).putString("telegram_send_error", result.reason).apply()
                is SendResult.Retryable -> { prefs.edit().putString("telegram_send_error", result.reason).apply(); return false }
                is SendResult.ConfigError -> { prefs.edit().putString("telegram_send_error", result.reason).apply(); return true }
            }
            delay(SEND_PAUSE_MS)
        }

        while (true) {
            val batch = db.unsent(BATCH_SIZE)
            if (batch.isEmpty()) break
            val text = if (batch.size == 1) format(batch[0], user) else formatBatch(batch, user)
            when (val result = TelegramSender.send(token, chatId, text)) {
                SendResult.Success -> db.markSentIds(batch.map { it.id })
                is SendResult.Unconfirmed -> {
                    // Dublikat yubormaslik uchun qayta urinmaymiz: yuborilgan deb belgilanadi
                    db.markSentIds(batch.map { it.id })
                    prefs.edit().putString("telegram_send_error", result.reason).apply()
                }
                is SendResult.Retryable -> {
                    db.recordFailure(batch.map { it.id }, result.reason)
                    prefs.edit().putString("telegram_send_error", result.reason).apply()
                    // WorkManager applies exponential backoff (30s base) on Result.retry().
                    return false
                }
                is SendResult.ConfigError -> {
                    db.recordFailure(batch.map { it.id }, result.reason)
                    prefs.edit().putString("telegram_send_error", result.reason).apply()
                    return true   // retry foydasiz (token/chat noto'g'ri)
                }
            }
            delay(SEND_PAUSE_MS)
        }
        db.purgeSent(System.currentTimeMillis() - 7 * 24 * 3600_000L)
        db.purgeOlderThan(System.currentTimeMillis() - 7 * 24 * 3600_000L)
        prefs.edit().remove("telegram_send_error").apply()
        true
    }

    private fun formatBatch(list: List<LocationEntry>, user: String): String {
        val f = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val lines = list.mapIndexed { i, e ->
            "${i + 1}. ${f.format(Date(e.timestamp))} · <a href=\"https://maps.google.com/?q=${e.lat},${e.lng}\">" +
                "${"%.5f".format(e.lat)}, ${"%.5f".format(e.lng)}</a> · 🔋${e.battery}%"
        }
        return "📦 <b>GPS Tracker: ${list.size} ta jamlangan nuqta</b> ⏳\n👤 $user\n\n" + lines.joinToString("\n")
    }

    private fun format(e: LocationEntry, user: String): String {
        val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
        val delayed = System.currentTimeMillis() - e.timestamp > 3 * 60_000L
        val head = if (e.isInitial) "🟢 <b>GPS Tracker Ishga Tushirildi</b>" else "📍 <b>GPS Tracker Hisoboti</b>"
        return listOf(
            head + if (delayed) " ⏳ <i>(kechikib yuborildi)</i>" else "",
            "",
            "👤 <b>Foydalanuvchi:</b> $user",
            "⏰ <b>Vaqt:</b> ${fmt.format(Date(e.timestamp))}",
            "🌐 <b>Kenglik:</b> ${e.lat}",
            "🌐 <b>Uzunlik:</b> ${e.lng}",
            "🎯 <b>Aniqlik:</b> ${"%.1f".format(e.accuracy)} metr",
            "🧭 <b>Tezlik:</b> ${"%.1f".format(e.speedKmh)} km/soat",
            "🔋 <b>Batareya:</b> ${e.battery}% (${if (e.charging) "quvvatlanmoqda ⚡" else "quvvatlanmayapti"})",
            "📶 <b>Tarmoq:</b> ${e.network}",
            "",
            "🔗 <a href=\"https://maps.google.com/?q=${e.lat},${e.lng}\">Google Maps'da ochish</a>"
        ).joinToString("\n")
    }
}
