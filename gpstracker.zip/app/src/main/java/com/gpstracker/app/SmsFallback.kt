package com.gpstracker.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Internet yo'q paytda oxirgi nuqtani SMS qiladi va masofaviy so'rovga SMS bilan javob beradi.
 * SMS ochiq matnda ketadi va foydalanuvchiga HAR SAFAR bildirishnoma ko'rsatiladi (yashirin emas).
 */
object SmsFallback {
    const val CHANNEL_ID = "gps_sms_notice"
    private const val NOTIFICATION_ID = 2001
    private const val K_LAST_SMS_TS = "sms_last_sent_ts"
    private const val K_LAST_SMS_ENTRY = "sms_last_entry_ts"
    private const val MIN_INTERVAL_MS = 55 * 60_000L   // soatiga 1 ta (15 daqiqalik tekshiruv jitter zaxirasi bilan)
    private const val MIN_AGE_MS = 2 * 60_000L

    private fun hasInternet(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager? =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    fun hasSendPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    /** SMS matni: ism, sana-vaqt, havola. ASCII (1-2 SMS ichida). */
    fun format(ctx: Context, e: LocationEntry, note: String): String {
        val user = AppPrefs.prefs(ctx).getString(AppPrefs.KEY_USER_NAME, "Noma'lum").orEmpty()
        val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US)
        return "GPS Tracker: $user\n" +
            "${fmt.format(Date(e.timestamp))}\n" +
            "https://maps.google.com/?q=${e.lat},${e.lng}\n" +
            note +
            (e.warning?.let { "\nDiqqat: $it" } ?: "")
    }

    @SuppressLint("MissingPermission")
    fun send(ctx: Context, phone: String, text: String): Boolean {
        if (phone.isBlank() || !hasSendPermission(ctx)) return false
        return try {
            val sms = smsManager(ctx.applicationContext) ?: return false
            sms.sendMultipartTextMessage(phone, null, sms.divideMessage(text), null, null)
            true
        } catch (ex: Exception) { false }
    }

    /** SMS haqiqatan tarmoqqa ketganini tasdiqlaydi (antenna yo'q bo'lsa false qaytaradi). */
    @SuppressLint("MissingPermission")
    suspend fun sendConfirmed(ctx: Context, phone: String, text: String): Boolean {
        if (phone.isBlank() || !hasSendPermission(ctx)) return false
        val app = ctx.applicationContext
        val sms = smsManager(app) ?: return false
        val parts = sms.divideMessage(text)
        val action = "com.gpstracker.app.SMS_SENT_" + System.nanoTime()
        var left = parts.size
        var allOk = true
        var rcv: android.content.BroadcastReceiver? = null
        return try {
            kotlinx.coroutines.withTimeoutOrNull(30_000L) {
                kotlinx.coroutines.suspendCancellableCoroutine<Boolean> { cont ->
                    val r = object : android.content.BroadcastReceiver() {
                        override fun onReceive(c: Context, i: android.content.Intent) {
                            if (resultCode != android.app.Activity.RESULT_OK) allOk = false
                            left--
                            if (left <= 0 && cont.isActive) cont.resume(allOk) {}
                        }
                    }
                    rcv = r
                    ContextCompat.registerReceiver(app, r, android.content.IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
                    val pi = android.app.PendingIntent.getBroadcast(app, 0,
                        android.content.Intent(action).setPackage(app.packageName),
                        android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
                    val sent = ArrayList<android.app.PendingIntent>(parts.map { pi })
                    try { sms.sendMultipartTextMessage(phone, null, parts, sent, null) }
                    catch (e: Exception) { if (cont.isActive) cont.resume(false) {} }
                }
            } == true
        } catch (e: kotlinx.coroutines.CancellationException) { throw e }
        catch (e: Exception) { false }
        finally { rcv?.let { runCatching { app.unregisterReceiver(it) } } }
    }

    @Synchronized
    private fun claim(p: android.content.SharedPreferences, now: Long): Long? {
        val prev = p.getLong(K_LAST_SMS_TS, 0L)
        if (now - prev < MIN_INTERVAL_MS) return null
        p.edit().putLong(K_LAST_SMS_TS, now).commit()      // oldindan band qilamiz: ikki marta ketmasin
        return prev
    }

    /** Internet yo'q: joylashuvni SMS qiladi (soatiga 1 marta, antenna bo'lsa). */
    fun maybeSend(ctx: Context, e: LocationEntry) {
        val app = ctx.applicationContext
        val p = AppPrefs.prefs(app)
        val phone = p.getString(AppPrefs.KEY_SMS_PHONE, "").orEmpty().trim()
        if (phone.isEmpty() || !Net.hasAntenna(app)) return
        val now = System.currentTimeMillis()
        if (hasInternet(app) && now - e.timestamp < MIN_AGE_MS) return    // internet bor: bir oz kutamiz
        val prev = claim(p, now) ?: return
        if (send(app, phone, format(app, e, "(Internet yo'q, SMS orqali yuborildi)"))) {
            p.edit().putLong(K_LAST_SMS_ENTRY, e.timestamp).apply()
            TrackingService.instance?.showSmsSent()
            notify(app, "SMS orqali yuborildi", "Internet yo'q: joylashuv $phone raqamiga SMS qilindi")
        } else {
            p.edit().putLong(K_LAST_SMS_TS, prev).apply()   // yuborilmadi: keyingi tekshiruvda qayta uriniladi
        }
    }

    /** Internet yo'q bo'lsa har soatda joylashuvni SMS qiladi (doimiy). */
    suspend fun hourlyOffline(ctx: Context) {
        val app = ctx.applicationContext
        val p = AppPrefs.prefs(app)
        if (!p.getBoolean(AppPrefs.KEY_TRACKING, false)) return
        if (hasInternet(app) || !Net.hasAntenna(app)) return
        if (p.getString(AppPrefs.KEY_SMS_PHONE, "").isNullOrBlank() || !hasSendPermission(app)) return
        val now = System.currentTimeMillis()
        if (now - p.getLong(K_LAST_SMS_TS, 0L) < MIN_INTERVAL_MS) return
        val db = QueueDb.get(app)
        var e = db.lastEntry()
        if (e == null || now - e.timestamp > 20 * 60_000L) {          // nuqta eskirgan: yangisini olamiz
            runCatching { TrackingCore.captureAndStore(app, false, force = true) }
            e = db.lastEntry()
        }
        e?.let { maybeSend(app, it) }
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "SMS xabarnomalari", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    fun notify(ctx: Context, title: String, text: String) {
        ensureChannel(ctx)
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText("$text ($t)")
            .setAutoCancel(true)
            .build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, n) }
        catch (ex: SecurityException) { }
    }
}
