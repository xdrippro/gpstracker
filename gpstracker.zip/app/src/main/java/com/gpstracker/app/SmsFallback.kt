package com.gpstracker.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Internet yo'q paytda oxirgi nuqtani SMS qiladi va masofaviy so'rovga SMS bilan javob beradi.
 * SMS ochiq matnda ketadi va foydalanuvchiga HAR SAFAR bildirishnoma ko'rsatiladi (yashirin emas).
 */
object SmsFallback {
    const val CHANNEL_ID = "gps_sms_notice"
    private const val NOTIFICATION_ID = 2001
    private const val K_LAST_SMS_TS = "sms_last_sent_ts"
    private const val K_LAST_SMS_ENTRY = "sms_last_entry_ts"
    private const val MIN_INTERVAL_MS = 30 * 60_000L
    private const val MIN_AGE_MS = 2 * 60_000L

    private fun hasInternet(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    @Suppress("DEPRECATION")
    private fun smsManager(ctx: Context): SmsManager? =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    fun hasSendPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    /** SMS matni: ism, sana-vaqt, havola. ASCII (1-2 SMS ichida). */
    fun format(ctx: Context, e: LocationEntry, note: String): String {
        val user = AppPrefs.prefs(ctx).getString(AppPrefs.KEY_USER_NAME, "Noma'lum").orEmpty()
        val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.US)
        return "GPS Tracker: $user\n" +
            "${fmt.format(Date(e.timestamp))}\n" +
            "https://maps.google.com/?q=${e.lat},${e.lng}\n" +
            note +
            (e.warning?.let { "\nDiqqat: $it" } ?: "")
    }

    @SuppressLint("MissingPermission")
    fun send(ctx: Context, phone: String, text: String): Boolean {
        if (phone.isBlank() || !hasSendPermission(ctx)) return false
        return try {
            val sms = smsManager(ctx.applicationContext) ?: return false
            sms.sendMultipartTextMessage(phone, null, sms.divideMessage(text), null, null)
            true
        } catch (ex: Exception) { false }
    }

    /** Internet yo'q: Telegram yuborilmagan eng oxirgi nuqtani SMS qiladi. */
    fun maybeSend(ctx: Context, e: LocationEntry) {
        val app = ctx.applicationContext
        val p = AppPrefs.prefs(app)
        val phone = p.getString(AppPrefs.KEY_SMS_PHONE, "").orEmpty().trim()
        if (phone.isEmpty()) return
        val now = System.currentTimeMillis()
        if (e.timestamp <= p.getLong(K_LAST_SMS_ENTRY, 0L)) return        // bu nuqta uchun SMS ketgan
        if (now - p.getLong(K_LAST_SMS_TS, 0L) < MIN_INTERVAL_MS) return  // tejash: 30 daqiqada 1 ta
        if (hasInternet(app) && now - e.timestamp < MIN_AGE_MS) return    // internet bor: bir oz kutamiz
        if (send(app, phone, format(app, e, "(Internet yo'q, SMS orqali yuborildi)"))) {
            p.edit().putLong(K_LAST_SMS_TS, now).putLong(K_LAST_SMS_ENTRY, e.timestamp).apply()
            notify(app, "SMS orqali yuborildi", "Internet yo'q: joylashuv $phone raqamiga SMS qilindi")
        }
    }

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "SMS xabarnomalari", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    fun notify(ctx: Context, title: String, text: String) {
        ensureChannel(ctx)
        val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val n = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title)
            .setContentText("$text ($t)")
            .setAutoCancel(true)
            .build()
        try { ctx.getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, n) }
        catch (ex: SecurityException) { }
    }
}
