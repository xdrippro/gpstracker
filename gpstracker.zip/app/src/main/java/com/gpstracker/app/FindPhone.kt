package com.gpstracker.app

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.delay

/**
 * "JOY OVOZ 1234": tizimning budilnik ovozi (budilnik kanali, "Bezovta qilmang" rejimida ham eshitiladi)
 * va chiroq miltillashi. 60 soniyadan keyin o'zi to'xtaydi. Bildirishnomadagi tugma bilan to'xtatiladi.
 */
class FindPhoneWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    companion object {
        const val WORK_NAME = "find_phone"
        private const val DURATION_MS = 60_000L
    }

    override suspend fun getForegroundInfo(): ForegroundInfo {
        SmsFallback.ensureChannel(applicationContext)
        val stop = WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
        val n = NotificationCompat.Builder(applicationContext, SmsFallback.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Telefonni qidirish")
            .setContentText("Ovoz va chiroq yoqildi")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "To'xtatish", stop)
            .build()
        return ForegroundInfo(2003, n)
    }

    override suspend fun doWork(): Result {
        val app = applicationContext
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val oldVol = am.getStreamVolume(AudioManager.STREAM_ALARM)
        var player: MediaPlayer? = null
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val camId = runCatching {
            cm.cameraIdList.firstOrNull {
                val c = cm.getCameraCharacteristics(it)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        }.getOrNull()
        try {
            runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0) }
            runCatching {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                player = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    setDataSource(app, uri)
                    isLooping = true
                    prepare()
                    start()
                }
            }
            val end = System.currentTimeMillis() + DURATION_MS
            var on = false
            while (System.currentTimeMillis() < end) {   // delay() bekor qilinganda (To'xtatish) to'xtaydi
                on = !on
                if (camId != null) runCatching { cm.setTorchMode(camId, on) }
                delay(250)
            }
        } finally {
            runCatching { player?.stop(); player?.release() }
            if (camId != null) runCatching { cm.setTorchMode(camId, false) }
            runCatching { am.setStreamVolume(AudioManager.STREAM_ALARM, oldVol, 0) }
        }
        return Result.success()
    }
}
