package com.gpstracker.app

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

private fun qrBitmap(text: String, size: Int = 600): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val px = IntArray(size * size) { i -> if (m.get(i % size, i / size)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
    return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
}

/** Monitoring ilovasini bog'lash: QR ichida kalit, raqam, parol va nom. Faqat 2 marta ko'rsatiladi. Skrinshot taqiqlangan. */
@Composable
fun PairingDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { AppPrefs.prefs(context) }
    var key by remember { mutableStateOf(SmsProto.ensureKeyBase64(context)) }
    var onlyEnc by remember { mutableStateOf(prefs.getBoolean(SmsProto.K_ONLY_ENC, false)) }
    var ownPhone by remember { mutableStateOf(prefs.getString("own_phone", "").orEmpty()) }
    val name = remember { prefs.getString(AppPrefs.KEY_USER_NAME, "").orEmpty().replace(";", " ").trim() }
    val code = remember { prefs.getString("sms_code_enc", null)?.let { AppPrefs.decrypt(it) }.orEmpty() }
    var qrOpen by remember { mutableStateOf(false) }
    var qrClosed by remember { mutableStateOf(false) }
    var regen by remember { mutableStateOf(0) }
    val ready = ownPhone.length == 9 && code.length == 4

    LaunchedEffect(ready, regen) {
        if (ready && !qrOpen) { if (SmsProto.consumeQrView(context)) qrOpen = true else qrClosed = true }
    }
    val qr = remember(qrOpen, key, ownPhone, ready) {
        if (qrOpen && ready) qrBitmap("GT2;$key;$ownPhone;$code;$name").asImageBitmap() else null
    }

    DisposableEffect(Unit) {
        val w = context.findActivity()?.window
        w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🔐 Monitoring bog'lash") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                androidx.compose.material3.OutlinedTextField(
                    value = ownPhone,
                    onValueChange = { v ->
                        ownPhone = v.filter { it.isDigit() }.take(9)
                        prefs.edit().putString("own_phone", ownPhone).apply()
                    },
                    label = { Text("Bu telefon raqami") },
                    prefix = { Text("+998 ") },
                    placeholder = { Text("XX XXX XX XX") },
                    singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                when {
                    code.length != 4 -> Text("Avval sozlamalarda SMS maxfiy kodini qayta saqlang (QR uchun kerak).")
                    ownPhone.length != 9 -> Text("QR uchun shu telefon raqamini kiriting.")
                    qr != null -> {
                        Image(bitmap = qr, contentDescription = "QR kod", modifier = Modifier.size(240.dp))
                        Text("Monitoring ilovasida skanerlang. QR faqat 2 marta ko'rsatiladi, hech kimga ko'rsatmang.")
                    }
                    qrClosed -> Text("QR yopilgan (2 marta ko'rsatildi). Qayta bog'lash uchun \"Yangi kalit\" ni bosing.")
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Faqat shifrlangan buyruqlar", modifier = Modifier.weight(1f))
                    Switch(checked = onlyEnc, onCheckedChange = {
                        onlyEnc = it; prefs.edit().putBoolean(SmsProto.K_ONLY_ENC, it).apply()
                    })
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Yopish") } },
        dismissButton = {
            TextButton(onClick = {
                key = SmsProto.regenerate(context)
                qrOpen = false; qrClosed = false; regen++
            }) { Text("Yangi kalit") }
        }
    )
}
