package com.gpstracker.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    companion object {
        // Bildirishnomadagi "To'xtatish" tugmasi shu amal bilan ilovani ochadi (PIN so'raladi)
        const val ACTION_REQUEST_STOP = "com.gpstracker.app.ACTION_REQUEST_STOP"
    }

    private var stopRequested by mutableStateOf(false)

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == ACTION_REQUEST_STOP) {
            stopRequested = true
        }
    }

    override fun onStart() {
        super.onStart()
        SessionLock.onEnter()
    }

    override fun onStop() {
        super.onStop()
        SessionLock.onLeave()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Ilova ochiq rangli, shuning uchun status va navigatsiya paneli belgilari doim to'q rangda
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            ),
            navigationBarStyle = SystemBarStyle.light(
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT
            )
        )
        super.onCreate(savedInstanceState)

        handleIntent(intent)
        // Ilova allaqachon ochiq/fonda bo'lganda kelgan yangi Intent
        addOnNewIntentListener { newIntent -> handleIntent(newIntent) }

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF059669),
                    secondary = Color(0xFF0D9488),
                    background = Color(0xFFF8FAFC),
                    surface = Color.White
                )
            ) {
                AppRoot(
                    stopRequested = stopRequested,
                    onStopRequestHandled = {
                        stopRequested = false
                        // Qayta yaratilganda (masalan, ekran aylanganda) so'rov yana ochilmasligi uchun
                        setIntent(Intent(this@MainActivity, MainActivity::class.java))
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackerAppScreen(
    stopRequested: Boolean = false,
    onStopRequestHandled: () -> Unit = {}
) {
    val context = LocalContext.current
    val prefs: SharedPreferences = remember { AppPrefs.prefs(context) }

    var userName by remember { mutableStateOf(prefs.getString(AppPrefs.KEY_USER_NAME, "") ?: "") }
    // Token Android Keystore orqali shifrlangan holda saqlanadi
    var botToken by remember { mutableStateOf(AppPrefs.getBotToken(context)) }
    var chatId by remember { mutableStateOf(prefs.getString(AppPrefs.KEY_CHAT_ID, "") ?: "") }
    var isTracking by remember { mutableStateOf(prefs.getBoolean(AppPrefs.KEY_TRACKING, false)) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showBackgroundPermissionDialog by remember { mutableStateOf(false) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showOemDialog by remember { mutableStateOf(false) }

    // Kuzatuvni to'xtatish (STOP tugmasi va bildirishnomadagi tasdiqlash dialogi uchun umumiy)
    val performStop: () -> Unit = {
        // Xizmatga ACTION_STOP Intent yuborish (shunda xizmat alarmni bekor qiladi, is_tracking ni false qiladi va o'ladi)
        stopTrackingService(context)
        isTracking = false
        prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
        Toast.makeText(context, "GPS Kuzatuv to'xtatildi", Toast.LENGTH_SHORT).show()
    }

    // SharedPreferences o'zgarganda UI ni sinxron yangilash (masalan, bildirishnomadagi To'xtatish bosilganda)
    DisposableEffect(Unit) {
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { sp, key ->
            if (key == AppPrefs.KEY_TRACKING) {
                isTracking = sp.getBoolean(AppPrefs.KEY_TRACKING, false)
            }
        }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    // 2-Bosqich: Background Location ruxsati (Android 10+)
    val smsPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    val backgroundLocationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            startTrackingService(context)
            isTracking = true
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, true).apply()
            Toast.makeText(context, "GPS Kuzatuv to'liq ishga tushirildi!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                context,
                "Eslatma: 'Har doim ruxsat berish' tanlanmasa, telefon qulflanganda GPS to'xtab qolishi mumkin.",
                Toast.LENGTH_LONG
            ).show()
            // Background ruxsatisiz trackingni faol deb belgilamaymiz.
            isTracking = false
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
            showBackgroundPermissionDialog = true
        }
    }

    // 1-Bosqich: Oldingi fon GPS va Bildirishnoma ruxsatlari
    val foregroundPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false

        if (fineLocationGranted) {
            // Android 10+ bo'lsa va Background ruxsati berilmagan bo'lsa so'rash
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val hasBackground = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_BACKGROUND_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (!hasBackground) {
                    showBackgroundPermissionDialog = true
                } else {
                    startTrackingService(context)
                    isTracking = true
                    prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, true).apply()
                }
            } else {
                startTrackingService(context)
                isTracking = true
                prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, true).apply()
            }
        } else {
            Toast.makeText(
                context,
                "Xato: Aniq GPS (ACCESS_FINE_LOCATION) ruxsati talab qilinadi!",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF059669)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "GPS Tracker",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showSettingsDialog = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Sozlamalar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Holat kartasi
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isTracking) Color(0xFFECFDF5) else Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Xizmat holati:",
                            fontSize = 14.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = if (isTracking) "FAOL (Har 1 soatda)" else "TO'XTATILGAN",
                            fontWeight = FontWeight.Bold,
                            color = if (isTracking) Color(0xFF059669) else Color(0xFF94A3B8)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (isTracking)
                            "GPS kuzatuv ishlamoqda. START bosilishi bilan xabar yuborildi va har 1 soatda avtomatik Telegram botga hisobot jo'natiladi."
                        else
                            "Kuzatuvni boshlash uchun ismingizni kiriting va START tugmasini bosing.",
                        fontSize = 13.sp,
                        color = Color(0xFF475569)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Ism kiritish maydoni (Talab 1)
            OutlinedTextField(
                value = userName,
                onValueChange = {
                    userName = it
                    prefs.edit().putString(AppPrefs.KEY_USER_NAME, it).apply()
                },
                label = { Text("Foydalanuvchi ismi") },
                placeholder = { Text("Masalan: Alisher Navoiy") },
                singleLine = true,
                enabled = !isTracking,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (botToken.isEmpty() || chatId.isEmpty()) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Telegram sozlamalari kiritilmagan",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            color = Color(0xFF92400E)
                        )
                        Text(
                            text = "Yuqoridagi (⚙️) belgisini bosib, Telegram Bot Token va Chat ID kiriting.",
                            fontSize = 12.sp,
                            color = Color(0xFFB45309)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            TextButton(onClick = { showOemDialog = true }, modifier = Modifier.fillMaxWidth()) {
                Text("⚙️ Batareya / Autostart sozlamalari")
            }

            val adminComp = remember { android.content.ComponentName(context, DeviceAdmin::class.java) }
            val dpm = remember { context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager }
            var adminActive by remember { mutableStateOf(dpm.isAdminActive(adminComp)) }
            val adminLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
            ) { adminActive = dpm.isAdminActive(adminComp) }
            TextButton(
                onClick = {
                    if (adminActive) {
                        prefs.edit().putBoolean(DeviceAdmin.K_SELF_DISABLE, true).apply()
                        dpm.removeActiveAdmin(adminComp)
                        adminActive = false
                    } else {
                        adminLauncher.launch(Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                            putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp)
                            putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                "Ilovani sozlamalardan oson o'chirib bo'lmaydi. Himoya o'chirilsa sizga ogohlantirish yuboriladi.")
                        })
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (adminActive) "🛡️ O'chirishdan himoya: YOQILGAN (o'chirish uchun bosing)" else "🛡️ O'chirishdan himoyani yoqish")
            }

            // START TUGMASI (Talab 1, 2, 10)
            Button(
                onClick = {
                    if (userName.isBlank()) {
                        Toast.makeText(context, "Iltimos, ismingizni kiriting!", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (botToken.isBlank() || chatId.isBlank()) {
                        Toast.makeText(context, "Telegram Bot Token va Chat ID ni sozlang!", Toast.LENGTH_SHORT).show()
                        showSettingsDialog = true
                        return@Button
                    }

                    val neededPermissions = mutableListOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        neededPermissions.add(Manifest.permission.POST_NOTIFICATIONS)
                    }

                    foregroundPermissionLauncher.launch(neededPermissions.toTypedArray())
                },
                enabled = !isTracking,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "START — KUZATUVNI BOSHLASH", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // STOP TUGMASI (Talab 6)
            OutlinedButton(
                onClick = { performStop() },
                enabled = isTracking,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFDC2626)
                )
            ) {
                Icon(Icons.Default.Stop, contentDescription = null, tint = Color(0xFFDC2626))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "STOP — TO'XTATISH", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }

    // Bildirishnomadagi "To'xtatish" bosilganda: PIN kiritilgandan keyin tasdiqlash
    if (stopRequested) {
        AlertDialog(
            onDismissRequest = onStopRequestHandled,
            title = { Text("Kuzatuvni to'xtatish", fontWeight = FontWeight.Bold) },
            text = { Text("GPS kuzatuvni to'xtatishni xohlaysizmi?") },
            confirmButton = {
                Button(
                    onClick = {
                        performStop()
                        onStopRequestHandled()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("To'xtatish")
                }
            },
            dismissButton = {
                TextButton(onClick = onStopRequestHandled) {
                    Text("Bekor qilish")
                }
            }
        )
    }

    // PIN kodni o'zgartirish (to'liq ekranli oyna)
    if (showChangePinDialog) {
        ChangePinDialog(onDismiss = { showChangePinDialog = false })
    }

    if (showOemDialog) { OemSetupDialog(onDismiss = { showOemDialog = false }) }

    // Background Location tushuntirish dialogi
    if (showBackgroundPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showBackgroundPermissionDialog = false },
            title = { Text("Doimiy Joylashuv Ruxsati", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Ilova telefon ekrani o'chiq vaqtida va har 1 soatda uzluksiz koordinata yuborishi uchun 'Har doim ruxsat berish' (Allow all the time) opsiyasini tanlashingiz lozim.",
                    fontSize = 13.sp,
                    color = Color(0xFF475569)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBackgroundPermissionDialog = false
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            backgroundLocationLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("Ruxsat berish")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showBackgroundPermissionDialog = false
                    // Ruxsat berilmasa kuzatuv boshlanmaydi.
                    isTracking = false
                    prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, false).apply()
                }) {
                    Text("O'tkazib yuborish")
                }
            }
        )
    }

    // Sozlamalar Dialogi (Bot Token va Chat ID - Talab 7)
    if (showSettingsDialog) {
        var tempToken by remember { mutableStateOf(botToken) }
        var tempChatId by remember { mutableStateOf(chatId) }
        var tempSmsPhone by remember { mutableStateOf((prefs.getString(AppPrefs.KEY_SMS_PHONE, "") ?: "").filter { it.isDigit() }.removePrefix("998").take(9)) }
        var tempSmsCode by remember { mutableStateOf("") }
        var isTokenVisible by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("Telegram Sozlamalari", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        text = "1-usul: Telegram",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Telegram botingiz ma'lumotlarini kiriting:",
                        fontSize = 13.sp,
                        color = Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempToken,
                        onValueChange = { tempToken = it },
                        label = { Text("Bot Token") },
                        placeholder = { Text("123456789:ABCdefGhIjk...") },
                        singleLine = true,
                        visualTransformation = if (isTokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isTokenVisible = !isTokenVisible }) {
                                Icon(
                                    imageVector = if (isTokenVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (isTokenVisible) "Yashirish" else "Ko'rsatish"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempChatId,
                        onValueChange = { tempChatId = it },
                        label = { Text("Chat ID") },
                        placeholder = { Text("Masalan: 12345678 yoki -100123456789") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "2-usul: SMS (internet yo'q bo'lsa)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Internet yo'q bo'lsa joy shu raqamga SMS bo'ladi. Shu raqamdan \"JOY XXXX\" yozsangiz, joy darhol yuboriladi. Har SMS'da telefonda bildirishnoma chiqadi.",
                        fontSize = 13.sp,
                        color = Color(0xFF64748B)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempSmsPhone,
                        onValueChange = { v -> tempSmsPhone = v.filter { it.isDigit() }.take(9) },
                        label = { Text("Telefon raqami") },
                        prefix = { Text("+998 ") },
                        placeholder = { Text("XX XXX XX XX") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = tempSmsCode,
                        onValueChange = { v -> tempSmsCode = v.filter { it.isDigit() }.take(4) },
                        label = { Text("Maxfiy kod") },
                        placeholder = { Text(if (prefs.contains(AppPrefs.KEY_SMS_CODE_HASH)) "Saqlangan (o'zgartirish uchun yangisini yozing)" else "XXXX") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = {
                            showSettingsDialog = false
                            showChangePinDialog = true
                        }
                    ) {
                        Text("PIN kodni o'zgartirish")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newToken = tempToken.trim()
                        val newChatId = tempChatId.trim()
                        val rawPhone = tempSmsPhone.filter { it.isDigit() }
                        val newPhone: String? = when {
                            rawPhone.isEmpty() -> ""
                            rawPhone.length == 9 -> "+998$rawPhone"
                            else -> null
                        }
                        val codeTxt = tempSmsCode.trim()
                        if (newPhone == null) {
                            Toast.makeText(context, "Raqam 9 ta raqamdan iborat bo'lsin (XX XXX XX XX)", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        if (codeTxt.isNotEmpty() && codeTxt.length != 4) {
                            Toast.makeText(context, "Maxfiy kod 4 ta raqamdan iborat bo'lsin", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        if (newPhone.isNotEmpty() && codeTxt.isEmpty() && !prefs.contains(AppPrefs.KEY_SMS_CODE_HASH)) {
                            Toast.makeText(context, "Maxfiy kodni kiriting", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        if (AppPrefs.setBotToken(context, newToken)) {
                            botToken = newToken
                            chatId = newChatId
                            val ed = prefs.edit().putString(AppPrefs.KEY_CHAT_ID, newChatId)
                                .putString(AppPrefs.KEY_SMS_PHONE, newPhone)
                            if (codeTxt.isNotEmpty()) ed.putString(AppPrefs.KEY_SMS_CODE_HASH, SmsCommand.hash(context, codeTxt))
                            ed.apply()
                            if (newPhone.isNotEmpty()) {
                                val need = arrayOf(android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS)
                                    .filter {
                                        androidx.core.content.ContextCompat.checkSelfPermission(context, it) !=
                                            android.content.pm.PackageManager.PERMISSION_GRANTED
                                    }
                                if (need.isNotEmpty()) smsPermissionLauncher.launch(need.toTypedArray())
                            }
                            showSettingsDialog = false
                            Toast.makeText(context, "Sozlamalar saqlandi!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(
                                context,
                                "Tokenni xavfsiz saqlab bo'lmadi. Qayta urinib ko'ring.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Text("Saqlash")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) {
                    Text("Bekor qilish")
                }
            }
        )
    }
}

private fun startTrackingService(context: Context) {
    // Ism, token va chat ID xizmat ichida AppPrefs orqali o'qiladi (tokenni Intent orqali uzatmaymiz)
    val serviceIntent = Intent(context, TrackingService::class.java).apply {
        action = TrackingService.ACTION_START
    }
    ContextCompat.startForegroundService(context, serviceIntent)
}

private fun stopTrackingService(context: Context) {
    val serviceIntent = Intent(context, TrackingService::class.java).apply {
        action = TrackingService.ACTION_STOP
    }
    context.startService(serviceIntent)
}
