-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes SourceFile,LineNumberTable

# OkHttp va Okio o'z consumer-proguard qoidalarini AAR ichida olib keladi,
# shuning uchun bu yerda faqat ogohlantirishlarni bostirish kifoya (butun
# kutubxonani "keep" qilish kerak emas, aks holda siqish ishlamay qoladi).
-dontwarn okhttp3.**
-dontwarn okio.**

# Google Play Services Location ham o'z qoidalarini olib keladi.
-dontwarn com.google.android.gms.**

# SmsCommandReceiver, BootReceiver va boshqa manifestda e'lon qilingan
# komponentlar AGP tomonidan avtomatik saqlanadi, qo'shimcha qoida kerak emas.
