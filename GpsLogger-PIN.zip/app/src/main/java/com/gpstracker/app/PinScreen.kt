package com.gpstracker.app

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val PinGreen = Color(0xFF059669)
private val PinBackground = Color(0xFFF8FAFC)

/** PIN kiritish paneli: sarlavha, nuqtalar va raqamlar klaviaturasi. */
@Composable
fun PinPad(
    title: String,
    subtitle: String,
    errorText: String?,
    pin: String,
    enabled: Boolean,
    onDigit: (Char) -> Unit,
    onBackspace: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PinBackground)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = PinGreen,
            modifier = Modifier.size(40.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0F172A)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = subtitle,
            fontSize = 14.sp,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(28.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            repeat(PinManager.PIN_LENGTH) { index ->
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(if (index < pin.length) PinGreen else Color(0xFFCBD5E1))
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = errorText ?: " ",
            fontSize = 13.sp,
            color = Color(0xFFDC2626),
            textAlign = TextAlign.Center,
            modifier = Modifier.height(36.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))

        val rows = listOf(
            listOf('1', '2', '3'),
            listOf('4', '5', '6'),
            listOf('7', '8', '9')
        )
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { digit ->
                    PinKey(label = digit.toString(), enabled = enabled) { onDigit(digit) }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Spacer(modifier = Modifier.size(76.dp))
            PinKey(label = "0", enabled = enabled) { onDigit('0') }
            PinKey(label = "⌫", enabled = enabled) { onBackspace() }
        }
    }
}

@Composable
private fun PinKey(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(Color(0xFFE2E8F0))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 26.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF0F172A)
        )
    }
}

/** Yangi PIN o'rnatish: ikki marta kiritiladi, mos kelsa onPinCreated chaqiriladi. */
@Composable
fun CreatePinScreen(
    title: String = "PIN kod o'rnating",
    onPinCreated: (String) -> Unit
) {
    var firstPin by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    PinPad(
        title = title,
        subtitle = if (firstPin == null) {
            "Ilovaga kirish uchun ${PinManager.PIN_LENGTH} xonali PIN kod kiriting"
        } else {
            "PIN kodni qayta kiriting"
        },
        errorText = error,
        pin = pin,
        enabled = true,
        onDigit = { digit ->
            if (pin.length < PinManager.PIN_LENGTH) {
                val newPin = pin + digit
                pin = newPin
                if (newPin.length == PinManager.PIN_LENGTH) {
                    val saved = firstPin
                    if (saved == null) {
                        firstPin = newPin
                        pin = ""
                        error = null
                    } else if (saved == newPin) {
                        onPinCreated(newPin)
                    } else {
                        firstPin = null
                        pin = ""
                        error = "PIN kodlar mos kelmadi. Qaytadan kiriting."
                    }
                }
            }
        },
        onBackspace = {
            if (pin.isNotEmpty()) pin = pin.dropLast(1)
        }
    )
}

/** Mavjud PIN ni tekshirish. To'g'ri bo'lsa onSuccess chaqiriladi. */
@Composable
fun VerifyPinScreen(
    subtitle: String = "PIN kodni kiriting",
    onSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var lockSeconds by remember { mutableStateOf((PinManager.lockRemainingMs(context) + 999L) / 1000L) }

    // Qulf davomida har soniyada qolgan vaqtni yangilab turadi
    LaunchedEffect(lockSeconds) {
        if (lockSeconds > 0L) {
            delay(1000L)
            lockSeconds = (PinManager.lockRemainingMs(context) + 999L) / 1000L
        }
    }

    PinPad(
        title = "GPS Tracker",
        subtitle = subtitle,
        errorText = if (lockSeconds > 0L) {
            "Juda ko'p noto'g'ri urinish. $lockSeconds soniyadan keyin qayta urinib ko'ring."
        } else {
            error
        },
        pin = pin,
        enabled = !busy && lockSeconds <= 0L,
        onDigit = { digit ->
            if (!busy && lockSeconds <= 0L && pin.length < PinManager.PIN_LENGTH) {
                val newPin = pin + digit
                pin = newPin
                if (newPin.length == PinManager.PIN_LENGTH) {
                    busy = true
                    scope.launch {
                        val ok = withContext(Dispatchers.Default) {
                            PinManager.verifyPin(context, newPin)
                        }
                        if (ok) {
                            PinManager.registerSuccess(context)
                            onSuccess()
                        } else {
                            val lockMs = PinManager.registerFailure(context)
                            pin = ""
                            error = "PIN kod noto'g'ri"
                            lockSeconds = (lockMs + 999L) / 1000L
                        }
                        busy = false
                    }
                }
            }
        },
        onBackspace = {
            if (!busy && pin.isNotEmpty()) pin = pin.dropLast(1)
        }
    )
}

/** Sozlamalardan PIN ni almashtirish: avval joriy PIN, keyin yangisi. */
@Composable
fun ChangePinDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var verified by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = PinBackground
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                if (!verified) {
                    VerifyPinScreen(subtitle = "Avval joriy PIN kodni kiriting") {
                        verified = true
                    }
                } else {
                    CreatePinScreen(title = "Yangi PIN kod") { newPin ->
                        scope.launch {
                            withContext(Dispatchers.Default) {
                                PinManager.setPin(context, newPin)
                            }
                            Toast.makeText(context, "PIN kod o'zgartirildi", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        }
                    }
                }
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                ) {
                    Text("Bekor qilish")
                }
            }
        }
    }
}
