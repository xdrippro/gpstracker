# Android GPS Tracker (Kotlin)

Telegram bot orqali ishga tushganda darhol va keyin har 1 soatda GPS joylashuvini yuboradigan Android ilovasi.

## Xususiyatlar
- MinSdk 29 (Android 10), CompileSdk/TargetSdk 33
- Foreground Service (doimiy bildirishnoma + "To'xtatish" tugmasi)
- Soatlik takrorlash: `AlarmManager.setAndAllowWhileIdle` (SCHEDULE_EXACT_ALARM ruxsati kerak emas, vaqt bir necha daqiqaga og'ishi mumkin)
- Telefon qayta yoqilganda (BOOT_COMPLETED) avtomatik tiklanadi (faqat kuzatuv faol bo'lgan bo'lsa)
- Xato bo'lsa qayta urinish: lokatsiya olinmasa 5 daqiqadan keyin (3 martagacha, keyin Telegramga ogohlantirish), tarmoq uzilsa 5 daqiqadan keyin (6 martagacha)
- Telegram xabari (HTML): ism, vaqt, kenglik, uzunlik, aniqlik, tezlik, batareya, tarmoq turi (Wi-Fi / Mobil internet), Google Maps havolasi
- Bot Token Android Keystore (AES-GCM) bilan shifrlanib saqlanadi; ism va Chat ID oddiy SharedPreferences'da; `allowBackup=false`
- Jetpack Compose & Material 3 interfeysi
- Ilovaga kirish PIN kod bilan himoyalangan (4 xonali, bank ilovalaridagi kabi)

## Android Studio'da ishga tushirish
1. Arxivni alohida papkaga oching (Unzip).
2. Android Studio: **File -> Open** orqali papkani tanlang. Gradle 8.2 ni Studio o'zi yuklaydi (`gradle/wrapper/gradle-wrapper.properties` bo'yicha).
3. Sync tugagach, telefonni USB orqali ulang (USB Debugging yoqilgan bo'lsin) va **Run 'app'** ni bosing.
4. APK kerak bo'lsa: **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.

## Terminaldan build (ixtiyoriy)
Arxivda `gradlew` fayli va `gradle-wrapper.jar` yo'q. Terminaldan `./gradlew` ishlatmoqchi bo'lsangiz, kompyuteringizda Gradle o'rnatilgan holda loyiha papkasida bir marta:

    gradle wrapper --gradle-version 8.2

buyrug'ini bajaring. U `gradlew`, `gradlew.bat` va `gradle-wrapper.jar` ni yaratadi.

## GitHub Actions
`.github/workflows/build-apk.yml` Gradle 8.2 ni o'zi o'rnatib `gradle assembleDebug` ni ishga tushiradi va APK'ni artifact sifatida yuklaydi.

## Telefon sozlamalari (Xiaomi, Samsung, Huawei, Vivo, Oppo)
1. **Joylashuv**: "Har doim ruxsat berish" (Allow all the time). Ilova buni START'dan keyin alohida so'raydi.
2. **Avto-ishga tushish (Auto-start)**: Xiaomi / Vivo / Oppo'da ilova sozlamalarida yoqing.
3. **Batareya**: ilova uchun "Cheklovlarsiz" (No restrictions) tanlang.

## Cheklovlar
- Ba'zi ishlab chiqaruvchilar (Xiaomi, Huawei va boshqalar) fon ilovalarini agressiv to'xtatadi, shuning uchun 3-band muhim. Ishonchlilik kafolatlanmaydi.
- Android 12+ da fon holatidan Foreground Service ishga tushirish cheklangan. Servis tizim tomonidan o'chirilsa, soatlik alarm uni qayta tiklay olmasligi mumkin. Real telefonda sinab ko'ring.
- Tarmoq turi faqat Wi-Fi / Mobil internet / Ethernet sifatida ko'rsatiladi (4G/5G ni aniqlash READ_PHONE_STATE ruxsatini talab qiladi).
- `compileSdk 34`, `targetSdk 33`. Google Play'ga yuklamoqchi bo'lsangiz, joriy targetSdk talabini tekshiring.
- Faqat o'zingiz yoki roziligini bergan odamlarning telefonida ishlating.

## PIN kod
- Birinchi ochilganda 4 xonali PIN o'rnatiladi (ikki marta kiritiladi). Keyingi har ochilishda PIN so'raladi.
- PIN oddiy matn sifatida saqlanmaydi: tuz (salt) bilan PBKDF2 xeshi saqlanadi.
- Ilova fonga o'tib, 60 soniyadan uzoq tursa, qaytganda yana PIN so'raladi.
- 5 marta noto'g'ri kiritilsa, ilova 30 soniyaga qulflanadi (keyingi xatolarda qulf davomi ikki baravar oshib boradi, eng ko'pi 15 daqiqa).
- PIN ni almashtirish: Sozlamalar (⚙️) -> "PIN kodni o'zgartirish" (avval joriy PIN so'raladi).
- Bildirishnomadagi "To'xtatish" tugmasi ilovani ochadi: PIN kiritilgach to'xtatishni tasdiqlaysiz.
- PIN faqat ilova oynasini himoya qiladi. GPS xizmati PIN'dan mustaqil ishlayveradi.
- PIN esdan chiqsa: telefon Sozlamalari -> Ilovalar -> GPS Tracker -> Xotira -> Ma'lumotlarni tozalash. Bunda Bot Token, Chat ID va ism ham o'chadi, ularni qayta kiritasiz.
