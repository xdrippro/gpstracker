package com.gpstracker.app

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object TelegramSender {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    /**
     * onResult(success, error, retryable):
     * retryable = true bo'lsa (tarmoq xatosi, 429, 5xx) keyinroq qayta urinish mantiqli.
     * 4xx xatolar (noto'g'ri token / chat ID) qayta urinish bilan hal bo'lmaydi.
     */
    fun sendMessage(
        botToken: String,
        chatId: String,
        htmlText: String,
        onResult: (success: Boolean, error: String?, retryable: Boolean) -> Unit
    ) {
        CoroutineScope(Dispatchers.IO).launch {
            var success = false
            var error: String? = null
            var retryable = false

            try {
                val cleanToken = botToken.trim().removePrefix("bot")
                val url = "https://api.telegram.org/bot$cleanToken/sendMessage"

                val jsonBody = JSONObject().apply {
                    put("chat_id", chatId.trim())
                    put("text", htmlText)
                    put("parse_mode", "HTML")
                    put("disable_web_page_preview", false)
                }

                val request = Request.Builder()
                    .url(url)
                    .post(jsonBody.toString().toRequestBody(JSON_MEDIA_TYPE))
                    .build()

                client.newCall(request).execute().use { response ->
                    val code = response.code
                    val responseText = response.body?.string().orEmpty()
                    if (response.isSuccessful) {
                        success = true
                        Log.d("TelegramSender", "Xabar jo'natildi. HTTP $code")
                    } else {
                        // Response obyektining o'zi logga yozilmaydi: uning URL'ida bot token bor.
                        val msg = "HTTP $code: $responseText"
                        error = msg
                        retryable = code == 429 || code >= 500
                        Log.e("TelegramSender", "Telegram xatosi: $msg")
                    }
                }
            } catch (e: IOException) {
                // e.message ishlatilmaydi: ayrim xatolarda URL (ya'ni token) bo'lishi mumkin.
                val msg = "Tarmoq xatosi: ${e.javaClass.simpleName}"
                error = msg
                retryable = true
                Log.e("TelegramSender", msg)
            } catch (e: Exception) {
                val msg = "Xatolik: ${e.javaClass.simpleName}"
                error = msg
                Log.e("TelegramSender", msg)
            }

            onResult(success, error, retryable)
        }
    }
}
