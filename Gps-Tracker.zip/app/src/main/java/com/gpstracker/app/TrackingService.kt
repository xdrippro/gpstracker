package com.gpstracker.app

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.location.Location
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TrackingService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var prefs: SharedPreferences
    private var wakeLock: PowerManager.WakeLock? = null

    // STOP bosilgandan keyin kechikib kelgan callbacklar alarmni qayta yoqib yubormasligi uchun
    @Volatile
    private var isStopped = false

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_HOURLY_TRIGGER = "ACTION_HOURLY_TRIGGER"

        const val CHANNEL_ID = "gps_tracker_channel"
        const val NOTIFICATION_ID = 1001

        private const val TAG = "TrackingService"
        private const val ALARM_REQUEST_CODE = 1002

        // 1 soat = 3,600,000 ms (Talab 3)
        const val INTERVAL_HOURLY_MS = 60 * 60 * 1000L

        // Lokatsiya olinmasa yoki tarmoq uzilsa 5 daqiqadan keyin qayta urinish
        const val INTERVAL_RETRY_MS = 5 * 60 * 1000L
        private const val MAX_LOCATION_RETRIES = 3
        private const val MAX_SEND_RETRIES = 6

        // Lokatsiya + Telegram so'rovi tugaguncha CPU uxlab qolmasligi uchun
        private const val WAKELOCK_TIMEOUT_MS = 90_000L
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        prefs = AppPrefs.prefs(this)
        createNotificationChannel()

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "GpsTracker:WakeLockTag"
        ).apply {
            setReferenceCounted(false)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // intent == null: tizim START_STICKY orqali servisni qayta tiklagan, oddiy soatlik sikl sifatida davom etamiz
        val action = intent?.action ?: ACTION_HOURLY_TRIGGER

        if (action == ACTION_STOP) {
            isStopped = true
            stopForegroundTracking()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val isInitial = action == ACTION_START

        // startForegroundService() chaqirilgan bo'lsa, 5 soniya ichida startForeground majburiy
        startForeground(
            NOTIFICATION_ID,
            buildOngoingNotification(if (isInitial) "GPS kuzatuv faol..." else "GPS yangilanmoqda...")
        )

        if (isInitial) {
            prefs.edit().putBoolean(AppPrefs.KEY_TRACKING, true).apply()
        } else if (!prefs.getBoolean(AppPrefs.KEY_TRACKING, false)) {
            // Kuzatuv to'xtatilgan (eski alarm yoki tizim qayta tiklashi): xizmat o'zini o'chiradi
            isStopped = true
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        isStopped = false
        acquireWakeLock(WAKELOCK_TIMEOUT_MS)

        // Zanjir uzilmasligi uchun keyingi alarm ishning BOSHIDA rejalashtiriladi.
        // Xatolik bo'lsa, quyida u qisqaroq (5 daqiqalik) alarm bilan almashtiriladi.
        scheduleNextAlarm(INTERVAL_HOURLY_MS)

        // Talab 10: START bosilganda DARHOL koordinatalarni yuborish
        captureLocationAndSend(isInitial)

        return START_STICKY
    }

    private fun acquireWakeLock(timeoutMs: Long) {
        try {
            wakeLock?.acquire(timeoutMs)
        } catch (e: Exception) {
            Log.e(TAG, "WakeLock olishda xatolik: ${e.message}")
        }
    }

    private fun releaseWakeLockSafely() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "WakeLock bo'shatishda xatolik: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun captureLocationAndSend(isInitial: Boolean) {
        try {
            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { location: Location? ->
                    if (location != null) {
                        onLocationReady(location, isInitial)
                    } else {
                        // Yangi lokatsiya bo'lmasa, oxirgi ma'lum lokatsiyani sinab ko'ramiz
                        fusedLocationClient.lastLocation
                            .addOnSuccessListener { lastLocation: Location? ->
                                if (lastLocation != null) {
                                    onLocationReady(lastLocation, isInitial)
                                } else {
                                    onLocationFailed("lokatsiya yo'q")
                                }
                            }
                            .addOnFailureListener { e -> onLocationFailed(e.message) }
                    }
                }
                .addOnFailureListener { e -> onLocationFailed(e.message) }
        } catch (e: Exception) {
            // Masalan, foydalanuvchi ruxsatni bekor qilgan (SecurityException)
            onLocationFailed(e.javaClass.simpleName)
        }
    }

    private fun onLocationReady(location: Location, isInitial: Boolean) {
        prefs.edit().putInt(AppPrefs.KEY_LOCATION_FAILS, 0).apply()
        sendTelemetryToTelegram(location, isInitial)
    }

    private fun onLocationFailed(reason: String?) {
        Log.w(TAG, "Lokatsiya olinmadi: $reason")
        val failures = prefs.getInt(AppPrefs.KEY_LOCATION_FAILS, 0) + 1

        if (failures < MAX_LOCATION_RETRIES) {
            prefs.edit().putInt(AppPrefs.KEY_LOCATION_FAILS, failures).apply()
            scheduleNextAlarm(INTERVAL_RETRY_MS)
            releaseWakeLockSafely()
        } else {
            // Bir necha marta ketma-ket muvaffaqiyatsiz: Telegramga bir marta ogohlantirish yuboramiz.
            // Keyingi urinish ish boshida qo'yilgan oddiy soatlik alarm bilan davom etadi.
            prefs.edit().putInt(AppPrefs.KEY_LOCATION_FAILS, 0).apply()
            sendLocationWarning()
        }
    }

    private fun sendLocationWarning() {
        val botToken = AppPrefs.getBotToken(this)
        val chatId = prefs.getString(AppPrefs.KEY_CHAT_ID, "") ?: ""
        if (botToken.isBlank() || chatId.isBlank()) {
            releaseWakeLockSafely()
            return
        }

        val name = TextUtils.htmlEncode(prefs.getString(AppPrefs.KEY_USER_NAME, "Noma'lum") ?: "Noma'lum")
        val text = "⚠️ <b>GPS Tracker ogohlantirishi</b>\n\n" +
                "👤 <b>Foydalanuvchi:</b> $name\n" +
                "Joylashuvni $MAX_LOCATION_RETRIES marta aniqlab bo'lmadi. " +
                "Telefonda GPS yoqilganini va ruxsatlarni tekshiring."

        TelegramSender.sendMessage(botToken, chatId, text) { _, _, _ ->
            releaseWakeLockSafely()
        }
    }

    private fun sendTelemetryToTelegram(location: Location, isInitial: Boolean) {
        val rawUserName = prefs.getString(AppPrefs.KEY_USER_NAME, "Noma'lum") ?: "Noma'lum"
        val botToken = AppPrefs.getBotToken(this)
        val chatId = prefs.getString(AppPrefs.KEY_CHAT_ID, "") ?: ""

        if (botToken.isBlank() || chatId.isBlank()) {
            Log.w(TAG, "Bot Token yoki Chat ID mavjud emas!")
            releaseWakeLockSafely()
            return
        }

        // Ismdagi <, >, &, " belgilari Telegram HTML parserini buzmasligi uchun
        val safeUserName = TextUtils.htmlEncode(rawUserName)

        val timeFormat = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault())
        val currentTime = timeFormat.format(Date())

        val latitude = location.latitude
        val longitude = location.longitude
        val accuracy = location.accuracy
        val speedKmh = if (location.hasSpeed()) location.speed * 3.6f else 0.0f

        val (batteryLevel, isCharging) = DeviceUtils.getBatteryInfo(this)
        val chargingText = if (isCharging) "quvvatlanmoqda ⚡" else "quvvatlanmayapti"
        val networkType = DeviceUtils.getNetworkType(this)

        val googleMapsUrl = "https://maps.google.com/?q=$latitude,$longitude"

        val headerTag = if (isInitial) {
            "🟢 <b>GPS Tracker Ishga Tushirildi (Darhol)</b>"
        } else {
            "📍 <b>GPS Tracker Hisoboti (1 soatlik)</b>"
        }

        val messageHtml = listOf(
            headerTag,
            "",
            "👤 <b>Foydalanuvchi:</b> $safeUserName",
            "⏰ <b>Vaqt:</b> $currentTime",
            "🌐 <b>Kenglik:</b> $latitude",
            "🌐 <b>Uzunlik:</b> $longitude",
            "🎯 <b>Aniqlik:</b> ${"%.1f".format(accuracy)} metr",
            "🧭 <b>Tezlik:</b> ${"%.1f".format(speedKmh)} km/soat",
            "🔋 <b>Batareya:</b> $batteryLevel% ($chargingText)",
            "📶 <b>Tarmoq:</b> $networkType",
            "",
            "🔗 <a href=\"$googleMapsUrl\">Google Maps'da ochish</a>"
        ).joinToString("\n")

        TelegramSender.sendMessage(botToken, chatId, messageHtml) { success, error, retryable ->
            releaseWakeLockSafely()
            if (success) {
                prefs.edit().putInt(AppPrefs.KEY_SEND_FAILS, 0).apply()
                updateNotification("Oxirgi yuborilgan vaqt: $currentTime")
            } else {
                Log.e(TAG, "Telegramga yuborish xatosi: $error")
                val failures = prefs.getInt(AppPrefs.KEY_SEND_FAILS, 0) + 1
                if (retryable && failures <= MAX_SEND_RETRIES) {
                    // Tarmoq yo'q bo'lsa 5 daqiqadan keyin qayta urinadi (eng ko'pi bilan MAX_SEND_RETRIES marta)
                    prefs.edit().putInt(AppPrefs.KEY_SEND_FAILS, failures).apply()
                    scheduleNextAlarm(INTERVAL_RETRY_MS)
                } else {
                    // Qayta urinib bo'lmaydi (masalan, noto'g'ri token) yoki limit tugadi: oddiy soatlik alarm qoladi
                    prefs.edit().putInt(AppPrefs.KEY_SEND_FAILS, 0).apply()
                }
            }
        }
    }

    /**
     * setAndAllowWhileIdle: SCHEDULE_EXACT_ALARM ruxsatini talab qilmaydi va Doze rejimida ham ishlaydi.
     * Vaqt aniq emas (bir necha daqiqa og'ishi mumkin), soatlik hisobot uchun bu yetarli.
     */
    private fun scheduleNextAlarm(delayMs: Long) {
        if (isStopped) return
        val pendingIntent = alarmPendingIntent(noCreate = false) ?: return
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setAndAllowWhileIdle(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + delayMs,
            pendingIntent
        )
    }

    private fun alarmPendingIntent(noCreate: Boolean): PendingIntent? {
        val triggerIntent = Intent(this, TrackingService::class.java).apply {
            action = ACTION_HOURLY_TRIGGER
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or
                (if (noCreate) PendingIntent.FLAG_NO_CREATE else PendingIntent.FLAG_UPDATE_CURRENT)
        return PendingIntent.getForegroundService(this, ALARM_REQUEST_CODE, triggerIntent, flags)
    }

    private fun stopForegroundTracking() {
        // BootReceiver va UI qayta yoqib yubormasligi uchun
        prefs.edit()
            .putBoolean(AppPrefs.KEY_TRACKING, false)
            .putInt(AppPrefs.KEY_LOCATION_FAILS, 0)
            .putInt(AppPrefs.KEY_SEND_FAILS, 0)
            .apply()

        val pendingIntent = alarmPendingIntent(noCreate = true)
        if (pendingIntent != null) {
            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }

        releaseWakeLockSafely()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "GPS Tracker Doimiy Xizmati",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Har 1 soatda GPS joylashuvni Telegramga jo'natish xizmati"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildOngoingNotification(content: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpenApp = PendingIntent.getActivity(
            this, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE
        )

        // Bildirishnomadagi "To'xtatish" tugmasi ilovani ochadi: PIN kiritilgach to'xtatish tasdiqlanadi.
        val stopIntent = Intent(this, MainActivity::class.java).apply {
            action = MainActivity.ACTION_REQUEST_STOP
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingStop = PendingIntent.getActivity(
            this, 1, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GPS Tracker Faol")
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingOpenApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_delete, "To'xtatish", pendingStop)
            .build()
    }

    private fun updateNotification(content: String) {
        // STOP'dan keyin kechikib kelgan callback bildirishnomani qayta chiqarib yubormasligi uchun
        if (isStopped) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildOngoingNotification(content))
    }

    override fun onDestroy() {
        super.onDestroy()
        isStopped = true
        releaseWakeLockSafely()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
