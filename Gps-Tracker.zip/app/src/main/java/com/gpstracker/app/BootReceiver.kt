package com.gpstracker.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat

/**
 * Talab 5: telefon qayta yoqilganda (BOOT_COMPLETED) kuzatuv avval faol bo'lgan bo'lsa, avtomatik ishga tushadi.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        val isBootAction = action == Intent.ACTION_BOOT_COMPLETED ||
                action == Intent.ACTION_MY_PACKAGE_REPLACED ||
                action == "android.intent.action.QUICKBOOT_POWERON" ||
                action == "com.htc.intent.action.QUICKBOOT_POWERON"

        if (!isBootAction) return

        Log.d("BootReceiver", "Qurilma qayta yoqildi / ilova yangilandi: $action")

        val prefs = AppPrefs.prefs(context)
        if (!prefs.getBoolean(AppPrefs.KEY_TRACKING, false)) return

        val botToken = AppPrefs.getBotToken(context)
        val chatId = prefs.getString(AppPrefs.KEY_CHAT_ID, "") ?: ""
        if (botToken.isBlank() || chatId.isBlank()) return

        Log.d("BootReceiver", "Kuzatuv avval faol bo'lgan, xizmat qayta ishga tushirilmoqda...")
        val serviceIntent = Intent(context, TrackingService::class.java).apply {
            this.action = TrackingService.ACTION_START
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
